-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 15. Dezember 2008 um 11:52
-- Server Version: 5.0.51
-- PHP-Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `rule1tool_dev`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `analysisfavourits`
--

CREATE TABLE IF NOT EXISTS `analysisfavourits` (
  `company_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `analysis_id` int(10) unsigned NOT NULL,
  `date_add` int(10) unsigned NOT NULL,
  `date_edit` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`company_id`,`user_id`),
  KEY `analysis_id` (`analysis_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `analysisfavourits`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `availablestocksonexchanges`
--

CREATE TABLE IF NOT EXISTS `availablestocksonexchanges` (
  `market_id` tinyint(4) NOT NULL,
  `company_id` int(10) unsigned NOT NULL,
  `symbol` varchar(4) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`market_id`,`company_id`),
  KEY `Symbol` (`symbol`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `availablestocksonexchanges`
--

INSERT INTO `availablestocksonexchanges` (`market_id`, `company_id`, `symbol`) VALUES
(1, 1, 'APC');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
  `company_id` int(10) unsigned NOT NULL auto_increment,
  `add_date` int(10) unsigned NOT NULL,
  `isin` varchar(12) collate utf8_unicode_ci NOT NULL,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `main_market` tinyint(4) default NULL,
  `picture_id` int(10) unsigned default NULL,
  `group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`company_id`),
  UNIQUE KEY `ISIN_2` (`isin`),
  UNIQUE KEY `group_id` (`group_id`),
  KEY `name` (`name`),
  KEY `main_market` (`main_market`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `companies`
--

INSERT INTO `companies` (`company_id`, `add_date`, `isin`, `name`, `main_market`, `picture_id`, `group_id`) VALUES
(1, 1224330972, 'US0378331005', 'Apple Inc.', 1, NULL, 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `countrycodes`
--

CREATE TABLE IF NOT EXISTS `countrycodes` (
  `ALPHA2` varchar(2) collate utf8_unicode_ci NOT NULL,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`ALPHA2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `countrycodes`
--

INSERT INTO `countrycodes` (`ALPHA2`, `name`) VALUES
('DE', 'Germany'),
('US', 'United States of America');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `gruppen`
--

CREATE TABLE IF NOT EXISTS `gruppen` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `date_add` int(10) unsigned NOT NULL,
  `date_edit` int(10) unsigned NOT NULL,
  `founder_id` int(10) unsigned NOT NULL,
  `open` enum('y','n') collate utf8_unicode_ci NOT NULL default 'y',
  `date_delete` int(10) unsigned default NULL,
  `delete_by` int(10) unsigned default NULL,
  `picture` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`),
  KEY `founder_id` (`founder_id`),
  KEY `delete_by` (`delete_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Daten für Tabelle `gruppen`
--

INSERT INTO `gruppen` (`id`, `date_add`, `date_edit`, `founder_id`, `open`, `date_delete`, `delete_by`, `picture`) VALUES
(2, 1223832429, 1223832429, 3, 'y', NULL, NULL, NULL),
(3, 1224330972, 1224330972, 3, 'y', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `gruppen_lokalisierung`
--

CREATE TABLE IF NOT EXISTS `gruppen_lokalisierung` (
  `group_id` int(10) unsigned NOT NULL,
  `language` set('de','en') collate utf8_unicode_ci NOT NULL default 'de',
  `title` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`group_id`,`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `gruppen_lokalisierung`
--

INSERT INTO `gruppen_lokalisierung` (`group_id`, `language`, `title`, `description`) VALUES
(2, 'de', 'Apple Inc.', 'Gruppe zum Unternehmen'),
(2, 'en', 'Apple Inc.', 'Gruppe zum Unternehmen'),
(3, 'de', 'Apple Inc.', 'Gruppe zum Unternehmen'),
(3, 'en', 'Apple Inc.', 'Gruppe zum Unternehmen');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `gruppen_members`
--

CREATE TABLE IF NOT EXISTS `gruppen_members` (
  `group_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `mtype_id` int(10) unsigned NOT NULL,
  `date_join` int(10) unsigned NOT NULL,
  `date_delete` int(10) unsigned default NULL,
  `delete_by` int(10) unsigned default NULL,
  PRIMARY KEY  (`group_id`,`user_id`),
  KEY `mtype_id` (`mtype_id`),
  KEY `user_id` (`user_id`),
  KEY `delete_by` (`delete_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `gruppen_members`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `gruppen_membertypes`
--

CREATE TABLE IF NOT EXISTS `gruppen_membertypes` (
  `mtype_id` int(10) unsigned NOT NULL auto_increment,
  `titel` varchar(255) character set latin1 NOT NULL,
  PRIMARY KEY  (`mtype_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `gruppen_membertypes`
--

INSERT INTO `gruppen_membertypes` (`mtype_id`, `titel`) VALUES
(1, 'Moderator'),
(2, 'Mitglied');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `gruppen_threads`
--

CREATE TABLE IF NOT EXISTS `gruppen_threads` (
  `thread_id` int(10) unsigned NOT NULL auto_increment,
  `group_id` int(10) unsigned NOT NULL,
  `title` varchar(255) collate utf8_unicode_ci NOT NULL,
  `type` tinyint(1) unsigned NOT NULL default '1',
  `date_add` int(10) unsigned NOT NULL,
  `date_edit` int(10) unsigned NOT NULL,
  `founder_id` int(10) unsigned NOT NULL,
  `date_delete` int(10) unsigned default NULL,
  `delete_by` int(10) unsigned default NULL,
  `analysis_id` int(10) unsigned default NULL,
  `language` set('de','en') collate utf8_unicode_ci NOT NULL default 'de',
  PRIMARY KEY  (`thread_id`),
  KEY `gruppen_id` (`group_id`),
  KEY `founder_id` (`founder_id`),
  KEY `delete_by` (`delete_by`),
  KEY `type` (`type`),
  KEY `analysis_id` (`analysis_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Daten für Tabelle `gruppen_threads`
--

INSERT INTO `gruppen_threads` (`thread_id`, `group_id`, `title`, `type`, `date_add`, `date_edit`, `founder_id`, `date_delete`, `delete_by`, `analysis_id`, `language`) VALUES
(1, 2, 'Allgemeines zum Unternehmen', 2, 1223832429, 1223832429, 3, NULL, NULL, NULL, 'de'),
(2, 2, 'Allgemeines zum Unternehmen', 2, 1223832429, 1223832429, 3, NULL, NULL, NULL, 'en'),
(3, 2, 'Analyse von mb vom 15.10.2008', 3, 1224095825, 1224095825, 3, NULL, NULL, NULL, 'de'),
(4, 2, 'Analyse von mb vom Oct 15, 2008', 3, 1224095825, 1224095825, 3, NULL, NULL, NULL, 'en'),
(5, 2, 'Analyse von mb vom 15.10.2008', 3, 1224096424, 1224096424, 3, NULL, NULL, NULL, 'de'),
(6, 2, 'Analyse von mb vom Oct 15, 2008', 3, 1224096424, 1224096424, 3, NULL, NULL, NULL, 'en'),
(7, 2, 'Analyse von mb vom 15.10.2008', 3, 1224096677, 1224096677, 3, NULL, NULL, NULL, 'de'),
(8, 2, 'Analyse von mb vom Oct 15, 2008', 3, 1224096677, 1224096677, 3, NULL, NULL, NULL, 'en'),
(9, 2, 'Analyse von mb vom 15.10.2008', 3, 1224096872, 1224096872, 3, NULL, NULL, NULL, 'de'),
(10, 2, 'Analyse von mb vom Oct 15, 2008', 3, 1224096872, 1224096872, 3, NULL, NULL, NULL, 'en'),
(11, 2, 'Analyse von mb vom 15.10.2008', 3, 1224096934, 1224096934, 3, NULL, NULL, NULL, 'de'),
(12, 2, 'Analyse von mb vom Oct 15, 2008', 3, 1224096934, 1224096934, 3, NULL, NULL, NULL, 'en'),
(13, 2, 'Analyse von mb vom 15.10.2008', 3, 1224096967, 1224096967, 3, NULL, NULL, NULL, 'de'),
(14, 2, 'Analyse von mb vom Oct 15, 2008', 3, 1224096967, 1224096967, 3, NULL, NULL, NULL, 'en'),
(15, 2, 'Analyse von mb vom 17.10.2008', 3, 1224220281, 1224220281, 3, NULL, NULL, NULL, 'de'),
(16, 2, 'Analyse von mb vom Oct 17, 2008', 3, 1224220281, 1224220281, 3, NULL, NULL, NULL, 'en'),
(17, 2, 'Analyse von mb vom 17.10.2008', 3, 1224221018, 1224221018, 3, NULL, NULL, NULL, 'de'),
(18, 2, 'Analyse von mb vom Oct 17, 2008', 3, 1224221018, 1224221018, 3, NULL, NULL, NULL, 'en'),
(19, 2, 'Analyse von mb vom 17.10.2008', 3, 1224221087, 1224221087, 3, NULL, NULL, NULL, 'de'),
(20, 2, 'Analyse von mb vom Oct 17, 2008', 3, 1224221087, 1224221087, 3, NULL, NULL, NULL, 'en'),
(21, 2, 'Analyse von mb vom 17.10.2008', 3, 1224246511, 1224246511, 3, NULL, NULL, NULL, 'de'),
(22, 2, 'Analyse von mb vom Oct 17, 2008', 3, 1224246511, 1224246511, 3, NULL, NULL, NULL, 'en'),
(23, 3, 'Allgemeines zum Unternehmen', 2, 1224330972, 1224330972, 3, NULL, NULL, NULL, 'de'),
(24, 3, 'Allgemeines zum Unternehmen', 2, 1224330972, 1224330972, 3, NULL, NULL, NULL, 'en'),
(25, 3, 'Analyse von mb vom 20.10.2008', 3, 1224529444, 1224529444, 3, NULL, NULL, NULL, 'de'),
(26, 3, 'Analyse von mb vom Oct 20, 2008', 3, 1224529444, 1224529444, 3, NULL, NULL, NULL, 'en'),
(27, 3, 'Analyse von mb vom 21.10.2008', 3, 1224590687, 1224590687, 3, NULL, NULL, NULL, 'de'),
(28, 3, 'Analyse von mb vom Oct 21, 2008', 3, 1224590687, 1224590687, 3, NULL, NULL, NULL, 'en');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `gruppen_thread_replies`
--

CREATE TABLE IF NOT EXISTS `gruppen_thread_replies` (
  `reply_id` int(10) unsigned NOT NULL auto_increment,
  `thread_id` int(10) unsigned NOT NULL,
  `writer_id` int(10) unsigned NOT NULL,
  `date_add` int(10) unsigned NOT NULL,
  `date_edit` int(10) unsigned NOT NULL,
  `text` text collate utf8_unicode_ci NOT NULL,
  `date_delete` int(10) unsigned default NULL,
  `delete_by` int(10) unsigned default NULL,
  PRIMARY KEY  (`reply_id`),
  KEY `thread_id` (`thread_id`),
  KEY `delete_by` (`delete_by`),
  KEY `writer_id` (`writer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `gruppen_thread_replies`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `gruppen_thread_typs`
--

CREATE TABLE IF NOT EXISTS `gruppen_thread_typs` (
  `type_id` tinyint(1) unsigned NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Daten für Tabelle `gruppen_thread_typs`
--

INSERT INTO `gruppen_thread_typs` (`type_id`, `name`) VALUES
(1, 'standard'),
(2, 'company_comments'),
(3, 'analysis_comments');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `invitations`
--

CREATE TABLE IF NOT EXISTS `invitations` (
  `invitation_id` int(10) unsigned NOT NULL auto_increment,
  `key` varchar(255) collate utf8_unicode_ci NOT NULL,
  `invitor` int(10) unsigned NOT NULL,
  `date_send` int(10) unsigned NOT NULL,
  `date_reg` int(10) unsigned default NULL,
  `invited` int(10) unsigned default NULL,
  PRIMARY KEY  (`invitation_id`),
  UNIQUE KEY `key` (`key`),
  KEY `invited` (`invited`),
  KEY `invitor` (`invitor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `invitations`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `keydataanalyses`
--

CREATE TABLE IF NOT EXISTS `keydataanalyses` (
  `analysis_id` int(10) unsigned NOT NULL auto_increment,
  `company_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `date_add` int(10) unsigned NOT NULL,
  `date_edit` int(10) unsigned NOT NULL,
  `note` text collate utf8_unicode_ci NOT NULL,
  `date_delete` int(10) unsigned default NULL,
  `delete_by` int(10) unsigned default NULL,
  `analysts_estimated_growth` double default NULL,
  `current_eps` double NOT NULL,
  `my_estimated_growth` double default NULL,
  `my_future_kgv` double default NULL,
  PRIMARY KEY  (`analysis_id`),
  KEY `company_id` (`company_id`),
  KEY `user_id` (`user_id`),
  KEY `delete_by` (`delete_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `keydataanalyses`
--

INSERT INTO `keydataanalyses` (`analysis_id`, `company_id`, `user_id`, `date_add`, `date_edit`, `note`, `date_delete`, `delete_by`, `analysts_estimated_growth`, `current_eps`, `my_estimated_growth`, `my_future_kgv`) VALUES
(1, 1, 1, 1224529443, 1224529443, 'sdfsdf', NULL, NULL, 23, 23, 23, 23),
(2, 1, 1, 1224590687, 1224590687, 'jkh', NULL, NULL, 2, 2, 2, 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `keydataanalyses_data`
--

CREATE TABLE IF NOT EXISTS `keydataanalyses_data` (
  `analysis_id` int(10) unsigned NOT NULL,
  `year` int(4) unsigned NOT NULL,
  `roic` double default NULL,
  `equity` double default NULL,
  `equity_rate` double default NULL,
  `depts` double default NULL,
  `revenue` double default NULL,
  `revenue_rate` double default NULL,
  `eps` double default NULL,
  `eps_rate` double default NULL,
  `income_after_tax` double default NULL,
  `cashflow` double default NULL,
  `cashflow_rate` double default NULL,
  `kgv` double default NULL,
  PRIMARY KEY  (`analysis_id`,`year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `keydataanalyses_data`
--

INSERT INTO `keydataanalyses_data` (`analysis_id`, `year`, `roic`, `equity`, `equity_rate`, `depts`, `revenue`, `revenue_rate`, `eps`, `eps_rate`, `income_after_tax`, `cashflow`, `cashflow_rate`, `kgv`) VALUES
(1, 1999, NULL, NULL, NULL, 22, 2, NULL, 22, NULL, 2, 2, NULL, 2),
(1, 2000, NULL, 22, NULL, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, 2),
(1, 2001, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 2, 22, NULL, 2),
(1, 2002, NULL, 2, NULL, 2, 2, NULL, NULL, NULL, 2, 2, NULL, 22),
(1, 2003, NULL, 2, NULL, 22, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(1, 2004, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(1, 2005, NULL, 324, NULL, 2, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(1, 2006, NULL, 22, NULL, 3, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(1, 2007, NULL, 2, NULL, 22, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(1, 2008, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 22, 3, NULL, 22),
(2, 1999, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(2, 2000, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(2, 2001, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(2, 2002, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(2, 2003, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(2, 2004, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(2, 2005, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(2, 2006, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(2, 2007, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 2, 2, NULL, 2),
(2, 2008, NULL, 2, NULL, 2, 2, NULL, 2, NULL, 2, 2, NULL, 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `logprofiler`
--

CREATE TABLE IF NOT EXISTS `logprofiler` (
  `id` int(11) NOT NULL auto_increment,
  `time_execution` double NOT NULL,
  `uri` varchar(255) collate utf8_unicode_ci NOT NULL,
  `date_add` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1462 ;

--
-- Daten für Tabelle `logprofiler`
--

INSERT INTO `logprofiler` (`id`, `time_execution`, `uri`, `date_add`) VALUES
(1, 0.792542, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222185919),
(2, 0.215217, '/rule1tool/trunk/htdocs/de/index/index', 1222185924),
(3, 0.192085, '/rule1tool/trunk/htdocs/de/stocks/index', 1222186016),
(4, 0.319991, '/rule1tool/trunk/htdocs/de/watchlist/index', 1222186018),
(5, 0.223655, '/rule1tool/trunk/htdocs/de/index/index', 1222186020),
(6, 0.555076, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222186025),
(7, 6.496271, '/rule1tool/trunk/htdocs/de/index/index', 1222186089),
(8, 0.308113, '/rule1tool/trunk/htdocs/de/index/index', 1222191179),
(9, 0.279912, '/rule1tool/trunk/htdocs/de/index/index', 1222194509),
(10, 0.297158, '/rule1tool/trunk/htdocs/de/index/index', 1222194643),
(11, 0.3739, '/rule1tool/trunk/htdocs/de/index/index', 1222194680),
(12, 0.32721, '/rule1tool/trunk/htdocs/de/index/index', 1222194894),
(13, 0.317082, '/rule1tool/trunk/htdocs/de/index/index', 1222195065),
(14, 0.405385, '/rule1tool/trunk/htdocs/de/index/index', 1222195160),
(15, 0.435244, '/rule1tool/trunk/htdocs/de/index/index', 1222195205),
(16, 0.41081, '/rule1tool/trunk/htdocs/de/index/index', 1222195261),
(17, 0.46699, '/rule1tool/trunk/htdocs/de/index/index', 1222195389),
(18, 0.413828, '/rule1tool/trunk/htdocs/de/index/index', 1222195450),
(19, 0.970192, '/rule1tool/trunk/htdocs/de/index/index', 1222195675),
(20, 0.760581, '/rule1tool/trunk/htdocs/de/index/index', 1222196079),
(21, 0.672461, '/rule1tool/trunk/htdocs/de/index/index', 1222196087),
(22, 0.714983, '/rule1tool/trunk/htdocs/de/index/index', 1222196114),
(23, 0.707987, '/rule1tool/trunk/htdocs/de/index/index', 1222196133),
(24, 0.73001, '/rule1tool/trunk/htdocs/de/index/index', 1222196148),
(25, 0.693121, '/rule1tool/trunk/htdocs/de/index/index', 1222196167),
(26, 0.724241, '/rule1tool/trunk/htdocs/de/index/index', 1222196172),
(27, 0.686255, '/rule1tool/trunk/htdocs/de/index/index', 1222196272),
(28, 0.71012, '/rule1tool/trunk/htdocs/de/index/index', 1222196408),
(29, 0.764654, '/rule1tool/trunk/htdocs/de/index/index', 1222196751),
(30, 0.703297, '/rule1tool/trunk/htdocs/de/index/index', 1222196756),
(31, 0.931073, '/rule1tool/trunk/htdocs/de/index/index', 1222196813),
(32, 1.214105, '/rule1tool/trunk/htdocs/de/index/index', 1222196819),
(33, 0.36375, '/rule1tool/trunk/htdocs/de/index/index', 1222196954),
(34, 0.335294, '/rule1tool/trunk/htdocs/de/index/index', 1222196980),
(35, 0.301903, '/rule1tool/trunk/htdocs/de/index/index', 1222197002),
(36, 0.325446, '/rule1tool/trunk/htdocs/de/index/index', 1222197021),
(37, 0.477866, '/rule1tool/trunk/htdocs/de/index/index', 1222197047),
(38, 0.421316, '/rule1tool/trunk/htdocs/de/index/index', 1222197057),
(39, 0.421035, '/rule1tool/trunk/htdocs/de/index/index', 1222197107),
(40, 0.413865, '/rule1tool/trunk/htdocs/de/index/index', 1222197660),
(41, 0.421598, '/rule1tool/trunk/htdocs/de/index/index', 1222197768),
(42, 0.41433, '/rule1tool/trunk/htdocs/de/index/index', 1222197879),
(43, 0.428696, '/rule1tool/trunk/htdocs/de/index/index', 1222197947),
(44, 0.403821, '/rule1tool/trunk/htdocs/de/index/index', 1222198206),
(45, 0.460697, '/rule1tool/trunk/htdocs/de/index/index', 1222198273),
(46, 0.423304, '/rule1tool/trunk/htdocs/de/index/index', 1222198352),
(47, 0.411996, '/rule1tool/trunk/htdocs/de/index/index', 1222198367),
(48, 0.40676, '/rule1tool/trunk/htdocs/de/index/index', 1222198428),
(49, 0.44272, '/rule1tool/trunk/htdocs/de/index/index', 1222198476),
(50, 0.430434, '/rule1tool/trunk/htdocs/de/index/index', 1222198559),
(51, 0.467918, '/rule1tool/trunk/htdocs/de/index/index', 1222199154),
(52, 0.351213, '/rule1tool/trunk/htdocs/de/index/index', 1222199239),
(53, 0.410669, '/rule1tool/trunk/htdocs/de/index/index', 1222199246),
(54, 0.41492, '/rule1tool/trunk/htdocs/de/index/index', 1222199582),
(55, 0.445571, '/rule1tool/trunk/htdocs/de/index/index', 1222199742),
(56, 1.617251, '/rule1tool/trunk/htdocs/de/index/index', 1222201317),
(57, 1.217354, '/rule1tool/trunk/htdocs/', 1222277186),
(58, 0.551545, '/rule1tool/trunk/htdocs/', 1222277260),
(59, 0.419196, '/rule1tool/trunk/htdocs/', 1222277296),
(60, 0.432248, '/rule1tool/trunk/htdocs/', 1222277330),
(61, 0.409943, '/rule1tool/trunk/htdocs/', 1222277363),
(62, 0.407883, '/rule1tool/trunk/htdocs/', 1222277386),
(63, 0.42064, '/rule1tool/trunk/htdocs/', 1222277412),
(64, 0.440873, '/rule1tool/trunk/htdocs/', 1222277438),
(65, 0.488699, '/rule1tool/trunk/htdocs/', 1222277626),
(66, 0.460428, '/rule1tool/trunk/htdocs/', 1222277640),
(67, 0.469977, '/rule1tool/trunk/htdocs/', 1222277654),
(68, 0.428667, '/rule1tool/trunk/htdocs/', 1222277662),
(69, 0.42565, '/rule1tool/trunk/htdocs/', 1222277673),
(70, 0.448174, '/rule1tool/trunk/htdocs/', 1222277748),
(71, 0.439979, '/rule1tool/trunk/htdocs/', 1222277761),
(72, 0.451882, '/rule1tool/trunk/htdocs/', 1222277773),
(73, 0.430459, '/rule1tool/trunk/htdocs/', 1222277890),
(74, 1.448269, '/rule1tool/trunk/htdocs/', 1222278248),
(75, 1.43208, '/rule1tool/trunk/htdocs/', 1222278290),
(76, 1.378019, '/rule1tool/trunk/htdocs/', 1222278347),
(77, 0.473217, '/rule1tool/trunk/htdocs/', 1222278509),
(78, 0.525275, '/rule1tool/trunk/htdocs/', 1222278524),
(79, 0.508687, '/rule1tool/trunk/htdocs/', 1222278568),
(80, 0.476931, '/rule1tool/trunk/htdocs/', 1222278582),
(81, 0.461267, '/rule1tool/trunk/htdocs/', 1222278745),
(82, 0.47913, '/rule1tool/trunk/htdocs/', 1222278761),
(83, 0.478276, '/rule1tool/trunk/htdocs/', 1222278772),
(84, 1.588688, '/rule1tool/trunk/htdocs/', 1222278964),
(85, 0.424032, '/rule1tool/trunk/htdocs/', 1222279451),
(86, 0.443753, '/rule1tool/trunk/htdocs/', 1222279474),
(87, 0.480286, '/rule1tool/trunk/htdocs/', 1222279535),
(88, 0.445437, '/rule1tool/trunk/htdocs/', 1222279631),
(89, 0.418971, '/rule1tool/trunk/htdocs/', 1222279680),
(90, 0.494842, '/rule1tool/trunk/htdocs/', 1222279762),
(91, 0.427187, '/rule1tool/trunk/htdocs/', 1222279792),
(92, 0.467768, '/rule1tool/trunk/htdocs/', 1222279839),
(93, 0.469856, '/rule1tool/trunk/htdocs/', 1222279890),
(94, 0.442284, '/rule1tool/trunk/htdocs/', 1222279969),
(95, 0.424342, '/rule1tool/trunk/htdocs/', 1222280033),
(96, 0.440976, '/rule1tool/trunk/htdocs/', 1222280076),
(97, 0.497382, '/rule1tool/trunk/htdocs/', 1222280239),
(98, 0.466955, '/rule1tool/trunk/htdocs/', 1222280307),
(99, 0.582395, '/rule1tool/trunk/htdocs/', 1222280442),
(100, 0.44155, '/rule1tool/trunk/htdocs/', 1222280488),
(101, 0.417594, '/rule1tool/trunk/htdocs/', 1222280711),
(102, 0.422503, '/rule1tool/trunk/htdocs/', 1222280726),
(103, 0.4457, '/rule1tool/trunk/htdocs/', 1222281543),
(104, 0.434948, '/rule1tool/trunk/htdocs/', 1222281556),
(105, 0.432737, '/rule1tool/trunk/htdocs/', 1222281574),
(106, 0.651251, '/rule1tool/trunk/htdocs/', 1222282241),
(107, 0.46246, '/rule1tool/trunk/htdocs/', 1222282251),
(108, 0.420372, '/rule1tool/trunk/htdocs/', 1222282281),
(109, 0.423564, '/rule1tool/trunk/htdocs/', 1222282292),
(110, 0.440656, '/rule1tool/trunk/htdocs/', 1222282328),
(111, 0.441551, '/rule1tool/trunk/htdocs/', 1222282375),
(112, 0.453764, '/rule1tool/trunk/htdocs/', 1222282403),
(113, 0.465088, '/rule1tool/trunk/htdocs/', 1222282435),
(114, 0.436241, '/rule1tool/trunk/htdocs/', 1222282452),
(115, 0.434924, '/rule1tool/trunk/htdocs/', 1222282475),
(116, 0.777699, '/rule1tool/trunk/htdocs/', 1222282586),
(117, 0.438673, '/rule1tool/trunk/htdocs/', 1222282599),
(118, 0.43978, '/rule1tool/trunk/htdocs/', 1222282680),
(119, 0.442187, '/rule1tool/trunk/htdocs/', 1222282724),
(120, 0.490089, '/rule1tool/trunk/htdocs/', 1222282755),
(121, 0.434333, '/rule1tool/trunk/htdocs/', 1222282826),
(122, 0.519927, '/rule1tool/trunk/htdocs/', 1222283142),
(123, 0.442205, '/rule1tool/trunk/htdocs/', 1222283281),
(124, 0.457585, '/rule1tool/trunk/htdocs/', 1222283336),
(125, 0.430738, '/rule1tool/trunk/htdocs/', 1222283577),
(126, 0.442488, '/rule1tool/trunk/htdocs/', 1222283598),
(127, 0.557323, '/rule1tool/trunk/htdocs/', 1222283934),
(128, 0.435702, '/rule1tool/trunk/htdocs/', 1222284026),
(129, 0.446231, '/rule1tool/trunk/htdocs/', 1222284108),
(130, 0.436277, '/rule1tool/trunk/htdocs/', 1222284281),
(131, 0.441302, '/rule1tool/trunk/htdocs/', 1222284300),
(132, 0.471163, '/rule1tool/trunk/htdocs/', 1222284339),
(133, 0.435351, '/rule1tool/trunk/htdocs/', 1222284347),
(134, 0.428057, '/rule1tool/trunk/htdocs/', 1222284366),
(135, 0.452564, '/rule1tool/trunk/htdocs/', 1222284400),
(136, 0.483852, '/rule1tool/trunk/htdocs/', 1222284934),
(137, 0.437405, '/rule1tool/trunk/htdocs/', 1222285095),
(138, 0.480963, '/rule1tool/trunk/htdocs/', 1222285164),
(139, 0.43346, '/rule1tool/trunk/htdocs/', 1222285180),
(140, 0.431734, '/rule1tool/trunk/htdocs/', 1222285204),
(141, 0.439163, '/rule1tool/trunk/htdocs/', 1222285235),
(142, 0.550487, '/rule1tool/trunk/htdocs/', 1222285305),
(143, 0.424396, '/rule1tool/trunk/htdocs/', 1222285382),
(144, 0.42428, '/rule1tool/trunk/htdocs/', 1222285459),
(145, 0.416682, '/rule1tool/trunk/htdocs/', 1222285470),
(146, 0.429448, '/rule1tool/trunk/htdocs/', 1222285483),
(147, 0.426159, '/rule1tool/trunk/htdocs/', 1222285531),
(148, 0.444945, '/rule1tool/trunk/htdocs/', 1222285548),
(149, 0.49534, '/rule1tool/trunk/htdocs/', 1222285577),
(150, 0.59374, '/rule1tool/trunk/htdocs/', 1222285611),
(151, 0.342312, '/rule1tool/trunk/htdocs/', 1222285783),
(152, 0.274471, '/rule1tool/trunk/htdocs/', 1222285808),
(153, 0.522806, '/rule1tool/trunk/htdocs/', 1222286023),
(154, 0.457655, '/rule1tool/trunk/htdocs/', 1222286073),
(155, 1.094388, '/rule1tool/trunk/htdocs/', 1222319697),
(156, 0.416136, '/rule1tool/trunk/htdocs/', 1222319816),
(157, 0.421497, '/rule1tool/trunk/htdocs/', 1222319920),
(158, 0.395058, '/rule1tool/trunk/htdocs/', 1222319975),
(159, 0.415261, '/rule1tool/trunk/htdocs/', 1222320008),
(160, 0.389219, '/rule1tool/trunk/htdocs/', 1222320029),
(161, 0.40558, '/rule1tool/trunk/htdocs/', 1222320149),
(162, 0.288943, '/rule1tool/trunk/htdocs/', 1222320180),
(163, 0.293951, '/rule1tool/trunk/htdocs/', 1222320202),
(164, 0.288695, '/rule1tool/trunk/htdocs/', 1222320224),
(165, 0.293432, '/rule1tool/trunk/htdocs/', 1222320251),
(166, 0.420518, '/rule1tool/trunk/htdocs/', 1222320312),
(167, 0.29348, '/rule1tool/trunk/htdocs/', 1222320364),
(168, 0.294183, '/rule1tool/trunk/htdocs/', 1222324685),
(169, 0.295129, '/rule1tool/trunk/htdocs/', 1222324728),
(170, 0.290262, '/rule1tool/trunk/htdocs/', 1222324772),
(171, 0.289882, '/rule1tool/trunk/htdocs/', 1222324931),
(172, 0.528236, '/rule1tool/trunk/htdocs/', 1222325297),
(173, 0.441879, '/rule1tool/trunk/htdocs/', 1222326547),
(174, 0.41978, '/rule1tool/trunk/htdocs/', 1222326636),
(175, 0.444127, '/rule1tool/trunk/htdocs/', 1222326903),
(176, 0.416742, '/rule1tool/trunk/htdocs/', 1222326926),
(177, 0.42643, '/rule1tool/trunk/htdocs/', 1222326957),
(178, 0.423474, '/rule1tool/trunk/htdocs/', 1222326985),
(179, 0.444131, '/rule1tool/trunk/htdocs/', 1222327000),
(180, 0.42899, '/rule1tool/trunk/htdocs/', 1222327072),
(181, 0.479391, '/rule1tool/trunk/htdocs/', 1222328716),
(182, 0.433577, '/rule1tool/trunk/htdocs/', 1222328729),
(183, 0.423835, '/rule1tool/trunk/htdocs/', 1222328741),
(184, 0.41774, '/rule1tool/trunk/htdocs/', 1222328863),
(185, 0.457351, '/rule1tool/trunk/htdocs/', 1222328978),
(186, 0.577498, '/rule1tool/trunk/htdocs/', 1222329774),
(187, 0.544339, '/rule1tool/trunk/htdocs/', 1222331140),
(188, 0.453654, '/rule1tool/trunk/htdocs/', 1222331749),
(189, 0.500327, '/rule1tool/trunk/htdocs/', 1222332366),
(190, 0.424365, '/rule1tool/trunk/htdocs/', 1222332423),
(191, 0.433176, '/rule1tool/trunk/htdocs/', 1222332441),
(192, 0.424535, '/rule1tool/trunk/htdocs/', 1222332667),
(193, 0.5681, '/rule1tool/trunk/htdocs/', 1222332683),
(194, 0.427632, '/rule1tool/trunk/htdocs/', 1222332762),
(195, 0.42706, '/rule1tool/trunk/htdocs/', 1222335447),
(196, 0.42589, '/rule1tool/trunk/htdocs/', 1222335483),
(197, 0.427094, '/rule1tool/trunk/htdocs/', 1222335500),
(198, 0.425686, '/rule1tool/trunk/htdocs/', 1222335526),
(199, 0.426034, '/rule1tool/trunk/htdocs/', 1222335626),
(200, 0.42184, '/rule1tool/trunk/htdocs/', 1222335738),
(201, 0.530583, '/rule1tool/trunk/htdocs/', 1222335762),
(202, 0.426003, '/rule1tool/trunk/htdocs/', 1222335779),
(203, 0.427876, '/rule1tool/trunk/htdocs/', 1222335965),
(204, 0.419413, '/rule1tool/trunk/htdocs/', 1222336008),
(205, 0.433125, '/rule1tool/trunk/htdocs/', 1222337157),
(206, 0.422398, '/rule1tool/trunk/htdocs/', 1222337277),
(207, 0.418981, '/rule1tool/trunk/htdocs/', 1222337321),
(208, 0.431122, '/rule1tool/trunk/htdocs/', 1222360170),
(209, 0.422132, '/rule1tool/trunk/htdocs/', 1222360220),
(210, 0.4382, '/rule1tool/trunk/htdocs/', 1222362207),
(211, 0.477102, '/rule1tool/trunk/htdocs/', 1222362599),
(212, 0.72528, '/rule1tool/trunk/htdocs/', 1222362663),
(213, 0.511402, '/rule1tool/trunk/htdocs/', 1222362728),
(214, 0.452153, '/rule1tool/trunk/htdocs/', 1222362757),
(215, 0.431425, '/rule1tool/trunk/htdocs/', 1222362832),
(216, 0.475742, '/rule1tool/trunk/htdocs/', 1222363120),
(217, 0.522559, '/rule1tool/trunk/htdocs/', 1222363214),
(218, 0.443479, '/rule1tool/trunk/htdocs/', 1222363222),
(219, 0.432315, '/rule1tool/trunk/htdocs/', 1222363232),
(220, 0.447441, '/rule1tool/trunk/htdocs/', 1222363243),
(221, 0.437822, '/rule1tool/trunk/htdocs/', 1222363253),
(222, 0.440618, '/rule1tool/trunk/htdocs/', 1222363262),
(223, 0.503336, '/rule1tool/trunk/htdocs/', 1222363271),
(224, 0.434247, '/rule1tool/trunk/htdocs/', 1222363286),
(225, 0.441449, '/rule1tool/trunk/htdocs/', 1222363298),
(226, 0.439001, '/rule1tool/trunk/htdocs/', 1222363331),
(227, 0.436832, '/rule1tool/trunk/htdocs/', 1222363348),
(228, 0.552662, '/rule1tool/trunk/htdocs/', 1222364447),
(229, 0.462737, '/rule1tool/trunk/htdocs/', 1222364675),
(230, 1.17975, '/rule1tool/trunk/htdocs/', 1222365270),
(231, 0.783595, '/rule1tool/trunk/htdocs/', 1222365270),
(232, 0.44988, '/rule1tool/trunk/htdocs/', 1222365333),
(233, 0.451911, '/rule1tool/trunk/htdocs/', 1222365345),
(234, 0.447033, '/rule1tool/trunk/htdocs/', 1222365355),
(235, 0.454794, '/rule1tool/trunk/htdocs/', 1222365367),
(236, 0.435933, '/rule1tool/trunk/htdocs/', 1222365401),
(237, 0.50293, '/rule1tool/trunk/htdocs/', 1222365438),
(238, 0.527728, '/rule1tool/trunk/htdocs/', 1222365450),
(239, 0.440044, '/rule1tool/trunk/htdocs/', 1222365472),
(240, 0.463487, '/rule1tool/trunk/htdocs/', 1222365487),
(241, 0.515323, '/rule1tool/trunk/htdocs/', 1222365560),
(242, 0.713287, '/rule1tool/trunk/htdocs/', 1222365581),
(243, 0.446507, '/rule1tool/trunk/htdocs/', 1222365657),
(244, 0.455035, '/rule1tool/trunk/htdocs/', 1222365743),
(245, 0.473788, '/rule1tool/trunk/htdocs/', 1222365762),
(246, 0.465422, '/rule1tool/trunk/htdocs/', 1222365792),
(247, 0.485151, '/rule1tool/trunk/htdocs/', 1222365900),
(248, 0.476483, '/rule1tool/trunk/htdocs/', 1222365915),
(249, 0.698222, '/rule1tool/trunk/htdocs/', 1222365929),
(250, 0.485656, '/rule1tool/trunk/htdocs/', 1222366059),
(251, 0.498625, '/rule1tool/trunk/htdocs/', 1222366077),
(252, 0.699448, '/rule1tool/trunk/htdocs/de/stocks/index', 1222366311),
(253, 0.452588, '/rule1tool/trunk/htdocs/de/index/index', 1222366313),
(254, 0.674036, '/rule1tool/trunk/htdocs/de/index/index', 1222366523),
(255, 0.444158, '/rule1tool/trunk/htdocs/de/index/index', 1222366619),
(256, 0.480976, '/rule1tool/trunk/htdocs/de/index/index', 1222366659),
(257, 0.451693, '/rule1tool/trunk/htdocs/de/index/index', 1222366670),
(258, 0.453899, '/rule1tool/trunk/htdocs/de/index/index', 1222366750),
(259, 4.09791, '/rule1tool/trunk/htdocs/', 1222405728),
(260, 3.704145, '/rule1tool/trunk/htdocs/', 1222405761),
(261, 3.937943, '/rule1tool/trunk/htdocs/', 1222405847),
(262, 2.98742, '/rule1tool/trunk/htdocs/', 1222406054),
(263, 3.134489, '/rule1tool/trunk/htdocs/', 1222406074),
(264, 0.438942, '/rule1tool/trunk/htdocs/', 1222406129),
(265, 2.646246, '/rule1tool/trunk/htdocs/', 1222406396),
(266, 0.435128, '/rule1tool/trunk/htdocs/', 1222406527),
(267, 0.427309, '/rule1tool/trunk/htdocs/', 1222407064),
(268, 0.752982, '/rule1tool/trunk/htdocs/', 1222412361),
(269, 0.983272, '/rule1tool/trunk/htdocs/', 1222412506),
(270, 0.765722, '/rule1tool/trunk/htdocs/', 1222412610),
(271, 1.189287, '/rule1tool/trunk/htdocs/', 1222412634),
(272, 0.965333, '/rule1tool/trunk/htdocs/', 1222412649),
(273, 0.710275, '/rule1tool/trunk/htdocs/', 1222412856),
(274, 0.620519, '/rule1tool/trunk/htdocs/', 1222412914),
(275, 0.555484, '/rule1tool/trunk/htdocs/', 1222412935),
(276, 0.564311, '/rule1tool/trunk/htdocs/', 1222412937),
(277, 0.737381, '/rule1tool/trunk/htdocs/', 1222412950),
(278, 0.725522, '/rule1tool/trunk/htdocs/', 1222412952),
(279, 0.818664, '/rule1tool/trunk/htdocs/', 1222412955),
(280, 0.63531, '/rule1tool/trunk/htdocs/', 1222413270),
(281, 0.63783, '/rule1tool/trunk/htdocs/', 1222413275),
(282, 0.713959, '/rule1tool/trunk/htdocs/', 1222413277),
(283, 0.75419, '/rule1tool/trunk/htdocs/', 1222413531),
(284, 0.526054, '/rule1tool/trunk/htdocs/', 1222413534),
(285, 0.633904, '/rule1tool/trunk/htdocs/', 1222413536),
(286, 0.752751, '/rule1tool/trunk/htdocs/', 1222413645),
(287, 0.517272, '/rule1tool/trunk/htdocs/', 1222413647),
(288, 0.593445, '/rule1tool/trunk/htdocs/', 1222413649),
(289, 0.515982, '/rule1tool/trunk/htdocs/', 1222417930),
(290, 0.449348, '/rule1tool/trunk/htdocs/', 1222417944),
(291, 0.563794, '/rule1tool/trunk/htdocs/', 1222418005),
(292, 0.554425, '/rule1tool/trunk/htdocs/en/', 1222418017),
(293, 0.24353, '/rule1tool/trunk/htdocs/en/watchlist/index', 1222435890),
(294, 0.433514, '/rule1tool/trunk/htdocs/en/watchlist/index', 1222435890),
(295, 0.283472, '/rule1tool/trunk/htdocs/en/watchlist/index', 1222435897),
(296, 0.556185, '/rule1tool/trunk/htdocs/en/stock/US0378331005', 1222435934),
(297, 0.38529, '/rule1tool/trunk/htdocs/en/stocks/search?needle=microsoft', 1222436081),
(298, 0.308468, '/rule1tool/trunk/htdocs/en/stocks/search?needle=yahoo', 1222436101),
(299, 0.237094, '/rule1tool/trunk/htdocs/en/error/notfound', 1222436124),
(300, 0.175742, '/rule1tool/trunk/htdocs/en/error/notfound', 1222436128),
(301, 0.27571, '/rule1tool/trunk/htdocs/en/portfolio/index', 1222436131),
(302, 0.464721, '/rule1tool/trunk/htdocs/en', 1222436137),
(303, 1.816397, '/rule1tool/trunk/htdocs/en', 1222438794),
(304, 0.841135, '/rule1tool/trunk/htdocs/en', 1222440697),
(305, 0.678701, '/rule1tool/trunk/htdocs/en', 1222440807),
(306, 0.576156, '/rule1tool/trunk/htdocs/en', 1222440869),
(307, 0.658693, '/rule1tool/trunk/htdocs/en', 1222440889),
(308, 0.632647, '/rule1tool/trunk/htdocs/en', 1222440924),
(309, 0.604687, '/rule1tool/trunk/htdocs/en', 1222440950),
(310, 0.667955, '/rule1tool/trunk/htdocs/en', 1222441039),
(311, 1.190459, '/rule1tool/trunk/htdocs/en', 1222441726),
(312, 0.614415, '/rule1tool/trunk/htdocs/en', 1222441809),
(313, 0.753431, '/rule1tool/trunk/htdocs/en', 1222441845),
(314, 0.719397, '/rule1tool/trunk/htdocs/en', 1222442081),
(315, 0.592654, '/rule1tool/trunk/htdocs/en', 1222442150),
(316, 0.610139, '/rule1tool/trunk/htdocs/en', 1222443086),
(317, 0.61111, '/rule1tool/trunk/htdocs/en', 1222443146),
(318, 0.916431, '/rule1tool/trunk/htdocs/en', 1222443769),
(319, 0.714389, '/rule1tool/trunk/htdocs/en', 1222443835),
(320, 0.70937, '/rule1tool/trunk/htdocs/en', 1222443927),
(321, 0.629468, '/rule1tool/trunk/htdocs/en', 1222443954),
(322, 0.61206, '/rule1tool/trunk/htdocs/en', 1222443975),
(323, 0.68751, '/rule1tool/trunk/htdocs/en', 1222444275),
(324, 0.745575, '/rule1tool/trunk/htdocs/en', 1222444646),
(325, 0.782936, '/rule1tool/trunk/htdocs/en', 1222448020),
(326, 0.825905, '/rule1tool/trunk/htdocs/en', 1222448412),
(327, 0.519935, '/rule1tool/trunk/htdocs/en', 1222448474),
(328, 0.525858, '/rule1tool/trunk/htdocs/en', 1222448489),
(329, 0.537437, '/rule1tool/trunk/htdocs/en', 1222448976),
(330, 0.853681, '/rule1tool/trunk/htdocs/en', 1222449140),
(331, 0.51762, '/rule1tool/trunk/htdocs/en', 1222449340),
(332, 0.539111, '/rule1tool/trunk/htdocs/en', 1222449425),
(333, 1.057463, '/rule1tool/trunk/htdocs/en', 1222449599),
(334, 0.499111, '/rule1tool/trunk/htdocs/en', 1222449602),
(335, 0.498666, '/rule1tool/trunk/htdocs/en', 1222449605),
(336, 0.505234, '/rule1tool/trunk/htdocs/en', 1222449607),
(337, 0.496655, '/rule1tool/trunk/htdocs/en', 1222449610),
(338, 0.51791, '/rule1tool/trunk/htdocs/en', 1222449647),
(339, 0.488857, '/rule1tool/trunk/htdocs/en', 1222449650),
(340, 0.499602, '/rule1tool/trunk/htdocs/en', 1222449653),
(341, 0.511412, '/rule1tool/trunk/htdocs/en', 1222449655),
(342, 0.50192, '/rule1tool/trunk/htdocs/en', 1222449657),
(343, 0.538675, '/rule1tool/trunk/htdocs/en', 1222449884),
(344, 0.481268, '/rule1tool/trunk/htdocs/en', 1222449963),
(345, 0.489624, '/rule1tool/trunk/htdocs/en', 1222449973),
(346, 0.49441, '/rule1tool/trunk/htdocs/en', 1222449983),
(347, 0.487473, '/rule1tool/trunk/htdocs/en', 1222450002),
(348, 0.479612, '/rule1tool/trunk/htdocs/en', 1222450115),
(349, 0.555934, '/rule1tool/trunk/htdocs/en', 1222450143),
(350, 0.582102, '/rule1tool/trunk/htdocs/en', 1222459325),
(351, 0.476638, '/rule1tool/trunk/htdocs/en', 1222459386),
(352, 0.509861, '/rule1tool/trunk/htdocs/en', 1222459413),
(353, 0.505394, '/rule1tool/trunk/htdocs/en', 1222459523),
(354, 0.605186, '/rule1tool/trunk/htdocs/en', 1222459770),
(355, 0.585788, '/rule1tool/trunk/htdocs/en', 1222460543),
(356, 0.494979, '/rule1tool/trunk/htdocs/en', 1222460570),
(357, 0.533113, '/rule1tool/trunk/htdocs/en', 1222460733),
(358, 0.630577, '/rule1tool/trunk/htdocs/en', 1222460824),
(359, 0.569327, '/rule1tool/trunk/htdocs/en', 1222460937),
(360, 0.521823, '/rule1tool/trunk/htdocs/en', 1222460993),
(361, 0.564518, '/rule1tool/trunk/htdocs/en', 1222461017),
(362, 0.496753, '/rule1tool/trunk/htdocs/en', 1222461053),
(363, 0.537688, '/rule1tool/trunk/htdocs/en', 1222461469),
(364, 0.602747, '/rule1tool/trunk/htdocs/en', 1222461824),
(365, 0.477658, '/rule1tool/trunk/htdocs/en', 1222461853),
(366, 0.479995, '/rule1tool/trunk/htdocs/en', 1222461927),
(367, 0.532453, '/rule1tool/trunk/htdocs/en', 1222462045),
(368, 0.511969, '/rule1tool/trunk/htdocs/en', 1222462160),
(369, 0.484747, '/rule1tool/trunk/htdocs/en', 1222462229),
(370, 1.027232, '/rule1tool/trunk/htdocs/en', 1222462581),
(371, 0.484516, '/rule1tool/trunk/htdocs/en', 1222462617),
(372, 0.47848, '/rule1tool/trunk/htdocs/en', 1222462712),
(373, 0.559476, '/rule1tool/trunk/htdocs/en', 1222462854),
(374, 0.585146, '/rule1tool/trunk/htdocs/en', 1222462906),
(375, 0.491797, '/rule1tool/trunk/htdocs/en', 1222462987),
(376, 0.473532, '/rule1tool/trunk/htdocs/en', 1222463034),
(377, 0.478607, '/rule1tool/trunk/htdocs/en', 1222463053),
(378, 0.476819, '/rule1tool/trunk/htdocs/en', 1222463101),
(379, 0.52623, '/rule1tool/trunk/htdocs/en', 1222463140),
(380, 1.251993, '/rule1tool/trunk/htdocs/', 1222508051),
(381, 0.521015, '/rule1tool/trunk/htdocs/', 1222508081),
(382, 0.563408, '/rule1tool/trunk/htdocs/', 1222508099),
(383, 0.549847, '/rule1tool/trunk/htdocs/', 1222508235),
(384, 0.512764, '/rule1tool/trunk/htdocs/', 1222508250),
(385, 0.527987, '/rule1tool/trunk/htdocs/', 1222508449),
(386, 0.560375, '/rule1tool/trunk/htdocs/', 1222510671),
(387, 0.499835, '/rule1tool/trunk/htdocs/', 1222510780),
(388, 0.516039, '/rule1tool/trunk/htdocs/', 1222510799),
(389, 0.63135, '/rule1tool/trunk/htdocs/', 1222510861),
(390, 0.51595, '/rule1tool/trunk/htdocs/', 1222510877),
(391, 0.528532, '/rule1tool/trunk/htdocs/', 1222510899),
(392, 0.547722, '/rule1tool/trunk/htdocs/', 1222511258),
(393, 0.602724, '/rule1tool/trunk/htdocs/', 1222511281),
(394, 0.402581, '/rule1tool/trunk/htdocs/', 1222512071),
(395, 0.476743, '/rule1tool/trunk/htdocs/', 1222512181),
(396, 0.462695, '/rule1tool/trunk/htdocs/', 1222512226),
(397, 0.664123, '/rule1tool/trunk/htdocs/', 1222512286),
(398, 0.489472, '/rule1tool/trunk/htdocs/', 1222512891),
(399, 0.67431, '/rule1tool/trunk/htdocs/', 1222521579),
(400, 0.472626, '/rule1tool/trunk/htdocs/', 1222521621),
(401, 0.488603, '/rule1tool/trunk/htdocs/', 1222521634),
(402, 0.467983, '/rule1tool/trunk/htdocs/', 1222521646),
(403, 0.46475, '/rule1tool/trunk/htdocs/', 1222521684),
(404, 0.534907, '/rule1tool/trunk/htdocs/', 1222524248),
(405, 0.496196, '/rule1tool/trunk/htdocs/', 1222524426),
(406, 0.509384, '/rule1tool/trunk/htdocs/', 1222524535),
(407, 0.485102, '/rule1tool/trunk/htdocs/', 1222524642),
(408, 0.491851, '/rule1tool/trunk/htdocs/', 1222524699),
(409, 0.488953, '/rule1tool/trunk/htdocs/', 1222524755),
(410, 0.497562, '/rule1tool/trunk/htdocs/', 1222524795),
(411, 0.484464, '/rule1tool/trunk/htdocs/', 1222524800),
(412, 0.503672, '/rule1tool/trunk/htdocs/', 1222524848),
(413, 0.507463, '/rule1tool/trunk/htdocs/', 1222524948),
(414, 0.47438, '/rule1tool/trunk/htdocs/', 1222524952),
(415, 0.92131, '/rule1tool/trunk/htdocs/', 1222525268),
(416, 0.477301, '/rule1tool/trunk/htdocs/', 1222525309),
(417, 0.482715, '/rule1tool/trunk/htdocs/', 1222525313),
(418, 0.479592, '/rule1tool/trunk/htdocs/', 1222525316),
(419, 0.494101, '/rule1tool/trunk/htdocs/', 1222525348),
(420, 0.495886, '/rule1tool/trunk/htdocs/', 1222525351),
(421, 0.490057, '/rule1tool/trunk/htdocs/', 1222525354),
(422, 0.576963, '/rule1tool/trunk/htdocs/', 1222525511),
(423, 0.47556, '/rule1tool/trunk/htdocs/', 1222525520),
(424, 0.476662, '/rule1tool/trunk/htdocs/', 1222525525),
(425, 0.606981, '/rule1tool/trunk/htdocs/', 1222525617),
(426, 0.321593, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222535192),
(427, 0.452514, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222535221),
(428, 0.575054, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222535733),
(429, 0.593833, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222535854),
(430, 0.977258, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536077),
(431, 1.380458, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536078),
(432, 0.614934, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536126),
(433, 0.532984, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536144),
(434, 0.560973, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536178),
(435, 0.580727, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536211),
(436, 0.537496, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536264),
(437, 0.87397, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536291),
(438, 0.599415, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536335),
(439, 0.597405, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536384),
(440, 0.55168, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536514),
(441, 0.611325, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536558),
(442, 0.544003, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536665),
(443, 0.597242, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222536684),
(444, 0.767392, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222537460),
(445, 0.599228, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222537544),
(446, 0.845294, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222537753),
(447, 0.59219, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222537765),
(448, 0.599216, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222537776),
(449, 0.611177, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222537832),
(450, 0.610332, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222537990),
(451, 0.609845, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222538191),
(452, 0.60376, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222538206),
(453, 0.669367, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222545783),
(454, 0.606286, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222545863),
(455, 0.949383, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222545960),
(456, 0.641322, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222545980),
(457, 0.708858, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222546046),
(458, 0.719809, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222546084),
(459, 0.880584, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222546102),
(460, 0.895956, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222546504),
(461, 1.161975, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222546509),
(462, 0.574596, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222546593),
(463, 0.611028, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222546642),
(464, 0.594487, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222546663),
(465, 0.593176, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222546716),
(466, 0.598115, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222546763),
(467, 0.606305, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222547239),
(468, 0.620351, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222547278),
(469, 0.606545, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222547336),
(470, 0.799566, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222547400),
(471, 0.609741, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222547501),
(472, 0.459644, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222547639),
(473, 0.602226, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222547659),
(474, 0.620153, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222547685),
(475, 0.589928, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222547761),
(476, 0.646825, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222547800),
(477, 0.591412, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222547806),
(478, 0.905125, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222552333),
(479, 0.861101, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222552459),
(480, 0.692134, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222552791),
(481, 0.769316, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553162),
(482, 0.612166, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553297),
(483, 0.635217, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553317),
(484, 0.577315, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553348),
(485, 0.68228, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553362),
(486, 0.604729, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553371),
(487, 0.616556, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553374),
(488, 0.625234, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553377),
(489, 0.621293, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553381),
(490, 0.601492, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553417),
(491, 0.532095, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553421),
(492, 0.527101, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553424),
(493, 0.519556, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553443),
(494, 0.72867, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553464),
(495, 0.606065, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553467),
(496, 0.669381, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553471),
(497, 0.599106, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553508),
(498, 0.583371, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553511),
(499, 0.67458, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553514),
(500, 0.663038, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553540),
(501, 0.549646, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553606),
(502, 0.513679, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553610),
(503, 0.761819, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222553613),
(504, 0.598873, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554199),
(505, 0.560397, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554232),
(506, 0.591855, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554263),
(507, 0.54838, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554458),
(508, 0.362148, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554469),
(509, 0.386252, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554473),
(510, 0.343529, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554482),
(511, 0.386467, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554487),
(512, 0.640301, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554508),
(513, 0.60315, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554512),
(514, 0.617797, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554515),
(515, 0.520626, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554712),
(516, 1.553839, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554813),
(517, 0.363154, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554817),
(518, 0.35892, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554819),
(519, 0.413543, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554822),
(520, 0.661112, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222554855),
(521, 0.644086, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222555851),
(522, 0.648854, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222555856),
(523, 0.742959, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222591909),
(524, 1.116854, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222591913),
(525, 0.962866, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222592147),
(526, 0.252811, '/rule1tool/trunk/htdocs/de/index/index', 1222592244),
(527, 0.494037, '/rule1tool/trunk/htdocs/de/watchlist/index', 1222592248),
(528, 0.224622, '/rule1tool/trunk/htdocs/de/error/notfound', 1222592251),
(529, 0.186367, '/rule1tool/trunk/htdocs/de/index/index', 1222592254),
(530, 0.173641, '/rule1tool/trunk/htdocs/de/stocks/index', 1222592267),
(531, 0.196852, '/rule1tool/trunk/htdocs/de/error/notfound', 1222592273),
(532, 0.18917, '/rule1tool/trunk/htdocs/de/index/index', 1222592288),
(533, 0.170101, '/rule1tool/trunk/htdocs/de/stocks/index', 1222592293),
(534, 0.411528, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222592300),
(535, 0.192326, '/rule1tool/trunk/htdocs/de/index/index', 1222592903),
(536, 0.184557, '/rule1tool/trunk/htdocs/de/error/notfound', 1222592907),
(537, 0.186124, '/rule1tool/trunk/htdocs/de/error/notfound', 1222592911),
(538, 0.188768, '/rule1tool/trunk/htdocs/de/cron/new-companies', 1222598591),
(539, 0.187603, '/rule1tool/trunk/htdocs/', 1222598600),
(540, 1.427046, '/rule1tool/trunk/htdocs/de/stocks/search?needle=bayer', 1222598609),
(541, 1.168278, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222598726),
(542, 1.468855, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222598791),
(543, 1.473398, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222598954),
(544, 1.241023, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222599011),
(545, 0.202814, '/rule1tool/trunk/htdocs/de/cron/new-companies', 1222599198),
(546, 1.178064, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222599206),
(547, 0.431176, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222599856),
(548, 0.385773, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222601518),
(549, 0.306002, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222602068),
(550, 0.48838, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222602152),
(551, 0.386565, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222602847),
(552, 0.561131, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222603197),
(553, 1.557592, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222603276),
(554, 7.177287, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222603379),
(555, 7.402571, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222603437),
(556, 1.35247, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222603566),
(557, 1.25874, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222603611),
(558, 7.201662, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222603633),
(559, 1.357431, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222604057),
(560, 1.449768, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222604233),
(561, 0.48225, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222604318),
(562, 0.756644, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222604716),
(563, 1.242047, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222605384),
(564, 6.975092, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222605407),
(565, 0.485521, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222605916),
(566, 0.614912, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222605984),
(567, 7.021247, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222606080),
(568, 0.737194, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222606125),
(569, 0.607552, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222606429),
(570, 0.562487, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222606551),
(571, 0.176653, '/rule1tool/trunk/htdocs/de/stocks/index', 1222608852),
(572, 0.753657, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222608870),
(573, 0.620717, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222608917),
(574, 0.642842, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222609366),
(575, 0.764273, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222609378),
(576, 0.639824, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222609520),
(577, 0.706391, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222609559),
(578, 0.389006, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222609569),
(579, 0.636184, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222609665),
(580, 0.52406, '/rule1tool/trunk/htdocs/de/stock/DE0005752000', 1222609697),
(581, 0.453385, '/rule1tool/trunk/htdocs/de/stock/DE000A0EAMM0', 1222609710),
(582, 0.421591, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222609717),
(583, 1.099601, '/rule1tool/trunk/htdocs/de/stocks/search?needle=apple', 1222609735),
(584, 0.478758, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222609752),
(585, 0.608663, '/rule1tool/trunk/htdocs/de/stocks/search?needle=united+internet', 1222609761),
(586, 0.962034, '/rule1tool/trunk/htdocs/de/stocks/search?needle=united', 1222609768),
(587, 0.481377, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222609781),
(588, 0.548964, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222611224),
(589, 0.622221, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222611765),
(590, 0.648196, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222611937),
(591, 0.60371, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222612001),
(592, 0.672354, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222612092),
(593, 0.716762, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222612537),
(594, 0.720683, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222612660),
(595, 0.744022, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222612755),
(596, 0.607035, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222612788),
(597, 0.903556, '/rule1tool/trunk/htdocs/en/stock/US0378331005', 1222612831),
(598, 0.572008, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222612836),
(599, 0.654116, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222612980),
(600, 0.698939, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222613002),
(601, 0.642735, '/rule1tool/trunk/htdocs/en/stock/US0378331005', 1222613030),
(602, 0.643691, '/rule1tool/trunk/htdocs/en/stock/US0378331005', 1222613276),
(603, 0.719765, '/rule1tool/trunk/htdocs/en/stock/US0378331005', 1222613407),
(604, 0.790383, '/rule1tool/trunk/htdocs/en/stock/US0378331005', 1222613484),
(605, 0.637011, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1222613493),
(606, 0.815227, '/rule1tool/trunk/htdocs/en/stock/US0378331005', 1222613499),
(607, 0.701532, '/rule1tool/trunk/htdocs/en/stock/US0378331005', 1222613516),
(608, 0.690863, '/rule1tool/trunk/htdocs/en/stock/DE0005089031', 1222613533),
(609, 0.756736, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222613569),
(610, 0.212186, '/rule1tool/trunk/htdocs/de/cron/new-companies', 1222613642),
(611, 0.663101, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222613650),
(612, 0.231089, '/rule1tool/trunk/htdocs/de/cron/historical-quotes', 1222613678),
(613, 0.754693, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222613694),
(614, 14.663118, '/rule1tool/trunk/htdocs/de/cron/historical-quotes', 1222613750),
(615, 0.719336, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222613754),
(616, 0.744249, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222613853),
(617, 0.8145, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222616664),
(618, 0.810998, '/rule1tool/trunk/htdocs/de/stock/DE0005089031', 1222617805),
(619, 0.221554, '/rule1tool/trunk/htdocs/de/error/notfound', 1222617865),
(620, 0.519735, '/rule1tool/trunk/htdocs/de/index/index', 1222617877),
(621, 0.242453, '/rule1tool/trunk/htdocs/de/index/index', 1222618142),
(622, 0.255613, '/rule1tool/trunk/htdocs/de/index/index', 1222618393),
(623, 0.217048, '/rule1tool/trunk/htdocs/de/index/index', 1222618402),
(624, 0.551943, '/rule1tool/trunk/htdocs/de/index/index', 1222709161),
(625, 1.470989, '/rule1tool/trunk/htdocs/de/stocks/search?needle=freenet', 1222709168),
(626, 0.261426, '/rule1tool/trunk/htdocs/de/stock/DE000A0EAMM0', 1222709170),
(627, 0.947235, '/rule1tool/trunk/htdocs/de/stock/DE000A0EAMM0', 1222709185),
(628, 1.305493, '/rule1tool/trunk/htdocs/de/stock/DE000A0EAMM0', 1222751986),
(629, 1.103357, '/rule1tool/trunk/htdocs/de/stock/DE000A0EAMM0', 1222871588),
(630, 0.502771, '/rule1tool/trunk/htdocs/', 1223054023),
(631, 0.202879, '/rule1tool/trunk/htdocs/', 1223054046),
(632, 0.201263, '/rule1tool/trunk/htdocs/?KeepThis=true&', 1223054051),
(633, 0.21479, '/rule1tool/trunk/htdocs/?KeepThis=true&', 1223054078),
(634, 0.218349, '/rule1tool/trunk/htdocs/?KeepThis=true&', 1223054907),
(635, 0.237394, '/rule1tool/trunk/htdocs/?KeepThis=true&', 1223060004),
(636, 0.701583, '/rule1tool/trunk/htdocs/', 1223153431),
(637, 0.291887, '/rule1tool/trunk/htdocs/', 1223153465),
(638, 0.286181, '/rule1tool/trunk/htdocs/', 1223153475),
(639, 0.28218, '/rule1tool/trunk/htdocs/', 1223153503),
(640, 0.400587, '/rule1tool/trunk/htdocs/', 1223153847),
(641, 0.30573, '/rule1tool/trunk/htdocs/', 1223153870),
(642, 0.304418, '/rule1tool/trunk/htdocs/', 1223153878),
(643, 0.338143, '/rule1tool/trunk/htdocs/', 1223153908),
(644, 0.316137, '/rule1tool/trunk/htdocs/', 1223153934),
(645, 0.294236, '/rule1tool/trunk/htdocs/', 1223153936),
(646, 0.296966, '/rule1tool/trunk/htdocs/', 1223153942),
(647, 0.439329, '/rule1tool/trunk/htdocs/', 1223154296),
(648, 0.364087, '/rule1tool/trunk/htdocs/', 1223154308),
(649, 0.871721, '/rule1tool/trunk/htdocs/', 1223195082),
(650, 0.528464, '/rule1tool/trunk/htdocs/', 1223195123),
(651, 0.328089, '/rule1tool/trunk/htdocs/', 1223195171),
(652, 0.329863, '/rule1tool/trunk/htdocs/', 1223195200),
(653, 0.324966, '/rule1tool/trunk/htdocs/', 1223195242),
(654, 0.495253, '/rule1tool/trunk/htdocs/', 1223196338),
(655, 0.401229, '/rule1tool/trunk/htdocs/', 1223196452),
(656, 0.297811, '/rule1tool/trunk/htdocs/', 1223196469),
(657, 0.312817, '/rule1tool/trunk/htdocs/', 1223196535),
(658, 0.388514, '/rule1tool/trunk/htdocs/', 1223197391),
(659, 0.290063, '/rule1tool/trunk/htdocs/', 1223197407),
(660, 0.310189, '/rule1tool/trunk/htdocs/', 1223200453),
(661, 0.312245, '/rule1tool/trunk/htdocs/', 1223200512),
(662, 0.285954, '/rule1tool/trunk/htdocs/', 1223200546),
(663, 0.332568, '/rule1tool/trunk/htdocs/', 1223200611),
(664, 0.406844, '/rule1tool/trunk/htdocs/', 1223201463),
(665, 0.660172, '/rule1tool/trunk/htdocs/', 1223201665),
(666, 0.383662, '/rule1tool/trunk/htdocs/', 1223201678),
(667, 0.405309, '/rule1tool/trunk/htdocs/', 1223201731),
(668, 0.613747, '/rule1tool/trunk/htdocs/', 1223204558),
(669, 0.36516, '/rule1tool/trunk/htdocs/?KeepThis=true&', 1223204671),
(670, 0.374509, '/rule1tool/trunk/htdocs/', 1223204719),
(671, 0.392243, '/rule1tool/trunk/htdocs/', 1223204726),
(672, 0.390864, '/rule1tool/trunk/htdocs/', 1223204737),
(673, 0.494978, '/rule1tool/trunk/htdocs/', 1223217208),
(674, 0.448813, '/rule1tool/trunk/htdocs/', 1223217371),
(675, 0.414093, '/rule1tool/trunk/htdocs/', 1223221022),
(676, 0.421832, '/rule1tool/trunk/htdocs/', 1223221083),
(677, 0.435488, '/rule1tool/trunk/htdocs/', 1223221191),
(678, 0.511292, '/rule1tool/trunk/htdocs/', 1223221272),
(679, 0.423522, '/rule1tool/trunk/htdocs/', 1223221304),
(680, 0.403988, '/rule1tool/trunk/htdocs/', 1223221391),
(681, 0.427856, '/rule1tool/trunk/htdocs/', 1223222305),
(682, 0.443662, '/rule1tool/trunk/htdocs/', 1223223028),
(683, 0.396959, '/rule1tool/trunk/htdocs/', 1223223054),
(684, 0.445951, '/rule1tool/trunk/htdocs/', 1223223132),
(685, 0.438828, '/rule1tool/trunk/htdocs/', 1223223146),
(686, 0.429551, '/rule1tool/trunk/htdocs/', 1223223163),
(687, 0.413053, '/rule1tool/trunk/htdocs/', 1223223207),
(688, 0.425019, '/rule1tool/trunk/htdocs/', 1223223301),
(689, 0.44606, '/rule1tool/trunk/htdocs/', 1223223481),
(690, 0.458955, '/rule1tool/trunk/htdocs/', 1223223505),
(691, 0.447542, '/rule1tool/trunk/htdocs/', 1223223521),
(692, 0.440119, '/rule1tool/trunk/htdocs/', 1223223538),
(693, 0.430402, '/rule1tool/trunk/htdocs/', 1223223560),
(694, 0.825552, '/rule1tool/trunk/htdocs/', 1223380526),
(695, 0.376744, '/rule1tool/trunk/htdocs/', 1223380623),
(696, 0.656039, '/rule1tool/trunk/htdocs/', 1223380678),
(697, 0.642723, '/rule1tool/trunk/htdocs/', 1223380734),
(698, 0.383349, '/rule1tool/trunk/htdocs/', 1223381191),
(699, 0.909276, '/rule1tool/trunk/htdocs/', 1223381211),
(700, 0.661816, '/rule1tool/trunk/htdocs/', 1223381361),
(701, 0.646659, '/rule1tool/trunk/htdocs/', 1223381440),
(702, 0.762646, '/rule1tool/trunk/htdocs/', 1223381615),
(703, 0.636397, '/rule1tool/trunk/htdocs/?company_id=&title=&note=&analysts_estimated_growth=&current_eps=&my_estimated_growth=&my_future_kgv=&keydata%5B1%5D%5Byear%5D=&keydata%5B2%5D%5Byear%5D=&keydata%5B3%5D%5Byear%5D=&keydata%5B4%5D%5Byear%5D=&keydata%5B5%5D%5Byear%5D=', 1223381654),
(704, 0.64818, '/rule1tool/trunk/htdocs/?company_id=&title=&note=&analysts_estimated_growth=&current_eps=&my_estimated_growth=&my_future_kgv=&keydata%5B1%5D%5Byear%5D=&keydata%5B2%5D%5Byear%5D=&keydata%5B3%5D%5Byear%5D=&keydata%5B4%5D%5Byear%5D=&keydata%5B5%5D%5Byear%5D=', 1223381828),
(705, 0.668295, '/rule1tool/trunk/htdocs/', 1223381879),
(706, 0.42422, '/rule1tool/trunk/htdocs/', 1223387813),
(707, 0.40421, '/rule1tool/trunk/htdocs/', 1223387822),
(708, 0.65212, '/rule1tool/trunk/htdocs/', 1223387965),
(709, 0.790286, '/rule1tool/trunk/htdocs/', 1223387992),
(710, 1.062625, '/rule1tool/trunk/htdocs/', 1223394756),
(711, 0.745353, '/rule1tool/trunk/htdocs/', 1223394824),
(712, 0.798026, '/rule1tool/trunk/htdocs/', 1223396695),
(713, 0.832452, '/rule1tool/trunk/htdocs/', 1223396711),
(714, 0.793147, '/rule1tool/trunk/htdocs/', 1223396746),
(715, 0.678566, '/rule1tool/trunk/htdocs/', 1223397628),
(716, 0.838664, '/rule1tool/trunk/htdocs/', 1223397780),
(717, 0.919935, '/rule1tool/trunk/htdocs/', 1223398226),
(718, 0.805022, '/rule1tool/trunk/htdocs/', 1223398280),
(719, 1.059116, '/rule1tool/trunk/htdocs/', 1223399153),
(720, 0.450478, '/rule1tool/trunk/htdocs/', 1223406224),
(721, 0.400063, '/rule1tool/trunk/htdocs/', 1223406337),
(722, 0.316181, '/rule1tool/trunk/htdocs/', 1223406344),
(723, 0.411812, '/rule1tool/trunk/htdocs/', 1223406761),
(724, 0.495964, '/rule1tool/trunk/htdocs/', 1223406844),
(725, 0.523668, '/rule1tool/trunk/htdocs/', 1223407136),
(726, 0.484504, '/rule1tool/trunk/htdocs/', 1223407159),
(727, 0.435302, '/rule1tool/trunk/htdocs/', 1223407300),
(728, 0.469731, '/rule1tool/trunk/htdocs/', 1223407334),
(729, 0.432242, '/rule1tool/trunk/htdocs/', 1223407355),
(730, 0.446293, '/rule1tool/trunk/htdocs/', 1223407368),
(731, 0.43006, '/rule1tool/trunk/htdocs/', 1223407392),
(732, 0.487635, '/rule1tool/trunk/htdocs/', 1223407429),
(733, 0.786427, '/rule1tool/trunk/htdocs/', 1223407474),
(734, 0.573901, '/rule1tool/trunk/htdocs/', 1223444952),
(735, 0.38911, '/rule1tool/trunk/htdocs/', 1223445044),
(736, 0.371783, '/rule1tool/trunk/htdocs/', 1223445057),
(737, 0.381767, '/rule1tool/trunk/htdocs/', 1223445076),
(738, 0.22093, '/rule1tool/trunk/htdocs/', 1223445089),
(739, 0.378394, '/rule1tool/trunk/htdocs/', 1223445103),
(740, 0.389915, '/rule1tool/trunk/htdocs/', 1223445137),
(741, 0.815527, '/rule1tool/trunk/htdocs/', 1223445170),
(742, 0.695957, '/rule1tool/trunk/htdocs/', 1223472948),
(743, 0.747549, '/rule1tool/trunk/htdocs/', 1223472959),
(744, 0.461897, '/rule1tool/trunk/htdocs/', 1223472991),
(745, 0.493579, '/rule1tool/trunk/htdocs/', 1223473000),
(746, 0.534414, '/rule1tool/trunk/htdocs/', 1223473040),
(747, 0.576496, '/rule1tool/trunk/htdocs/', 1223473042),
(748, 0.601764, '/rule1tool/trunk/htdocs/', 1223473070),
(749, 0.570683, '/rule1tool/trunk/htdocs/', 1223473073),
(750, 0.53181, '/rule1tool/trunk/htdocs/', 1223473084),
(751, 0.5082, '/rule1tool/trunk/htdocs/', 1223473102),
(752, 0.500495, '/rule1tool/trunk/htdocs/', 1223473105),
(753, 0.557986, '/rule1tool/trunk/htdocs/', 1223473132),
(754, 0.664373, '/rule1tool/trunk/htdocs/', 1223473135),
(755, 0.596603, '/rule1tool/trunk/htdocs/', 1223473138),
(756, 0.592993, '/rule1tool/trunk/htdocs/', 1223473141),
(757, 0.580187, '/rule1tool/trunk/htdocs/', 1223473164),
(758, 0.681133, '/rule1tool/trunk/htdocs/', 1223473166),
(759, 1.045924, '/rule1tool/trunk/htdocs/', 1223473167),
(760, 0.475184, '/rule1tool/trunk/htdocs/', 1223473169),
(761, 0.595884, '/rule1tool/trunk/htdocs/', 1223473172),
(762, 0.459689, '/rule1tool/trunk/htdocs/', 1223473240),
(763, 0.474942, '/rule1tool/trunk/htdocs/', 1223474182),
(764, 0.700383, '/rule1tool/trunk/htdocs/', 1223474242),
(765, 0.687759, '/rule1tool/trunk/htdocs/', 1223474371),
(766, 0.316465, '/rule1tool/trunk/htdocs/', 1223495740),
(767, 1.260368, '/rule1tool/trunk/htdocs/', 1223495766),
(768, 0.966308, '/rule1tool/trunk/htdocs/', 1223495788),
(769, 0.874906, '/rule1tool/trunk/htdocs/', 1223495840),
(770, 1.179716, '/rule1tool/trunk/htdocs/', 1223495877),
(771, 0.984975, '/rule1tool/trunk/htdocs/', 1223495903),
(772, 1.003487, '/rule1tool/trunk/htdocs/', 1223496011),
(773, 0.981146, '/rule1tool/trunk/htdocs/', 1223496018),
(774, 0.873239, '/rule1tool/trunk/htdocs/', 1223496111),
(775, 1.189633, '/rule1tool/trunk/htdocs/', 1223496550),
(776, 0.701245, '/rule1tool/trunk/htdocs/', 1223496558),
(777, 1.068867, '/rule1tool/trunk/htdocs/', 1223496570),
(778, 0.804125, '/rule1tool/trunk/htdocs/en', 1223496659),
(779, 0.997967, '/rule1tool/trunk/htdocs/en', 1223496667),
(780, 1.010243, '/rule1tool/trunk/htdocs/en', 1223496676),
(781, 0.978611, '/rule1tool/trunk/htdocs/en', 1223496684),
(782, 0.70777, '/rule1tool/trunk/htdocs/', 1223497143),
(783, 1.016851, '/rule1tool/trunk/htdocs/', 1223497155),
(784, 1.021018, '/rule1tool/trunk/htdocs/', 1223497165),
(785, 1.002558, '/rule1tool/trunk/htdocs/', 1223497211),
(786, 0.969071, '/rule1tool/trunk/htdocs/', 1223497216),
(787, 0.970402, '/rule1tool/trunk/htdocs/', 1223497221),
(788, 1.050503, '/rule1tool/trunk/htdocs/', 1223497315),
(789, 1.12907, '/rule1tool/trunk/htdocs/', 1223497501),
(790, 1.055499, '/rule1tool/trunk/htdocs/', 1223497509),
(791, 1.040328, '/rule1tool/trunk/htdocs/', 1223497515),
(792, 1.195786, '/rule1tool/trunk/htdocs/', 1223497744),
(793, 1.043336, '/rule1tool/trunk/htdocs/', 1223497749),
(794, 1.162361, '/rule1tool/trunk/htdocs/', 1223497754),
(795, 0.670739, '/rule1tool/trunk/htdocs/', 1223497761),
(796, 1.058511, '/rule1tool/trunk/htdocs/', 1223497771),
(797, 0.97465, '/rule1tool/trunk/htdocs/', 1223497780),
(798, 1.359108, '/rule1tool/trunk/htdocs/', 1223497841),
(799, 0.990994, '/rule1tool/trunk/htdocs/', 1223497857),
(800, 0.972327, '/rule1tool/trunk/htdocs/', 1223497875),
(801, 0.992987, '/rule1tool/trunk/htdocs/', 1223497914),
(802, 0.875518, '/rule1tool/trunk/htdocs/', 1223497924);
INSERT INTO `logprofiler` (`id`, `time_execution`, `uri`, `date_add`) VALUES
(803, 0.827824, '/rule1tool/trunk/htdocs/', 1223497938),
(804, 0.602907, '/rule1tool/trunk/htdocs/', 1223638631),
(805, 1.014401, '/rule1tool/trunk/htdocs/', 1223638780),
(806, 1.038743, '/rule1tool/trunk/htdocs/', 1223638851),
(807, 0.783922, '/rule1tool/trunk/htdocs/', 1223638891),
(808, 0.789198, '/rule1tool/trunk/htdocs/', 1223638920),
(809, 0.765991, '/rule1tool/trunk/htdocs/', 1223638967),
(810, 0.757095, '/rule1tool/trunk/htdocs/', 1223639001),
(811, 0.774892, '/rule1tool/trunk/htdocs/', 1223639340),
(812, 0.746265, '/rule1tool/trunk/htdocs/', 1223639348),
(813, 0.782974, '/rule1tool/trunk/htdocs/', 1223639373),
(814, 2.89084, '/rule1tool/trunk/htdocs/', 1223719563),
(815, 1.158114, '/rule1tool/trunk/htdocs/', 1223721468),
(816, 0.740901, '/rule1tool/trunk/htdocs/', 1223721524),
(817, 0.656422, '/rule1tool/trunk/htdocs/', 1223721622),
(818, 0.632069, '/rule1tool/trunk/htdocs/', 1223721652),
(819, 0.80016, '/rule1tool/trunk/htdocs/', 1223721677),
(820, 0.662363, '/rule1tool/trunk/htdocs/', 1223721697),
(821, 0.888151, '/rule1tool/trunk/htdocs/', 1223721724),
(822, 0.907915, '/rule1tool/trunk/htdocs/', 1223721801),
(823, 0.889439, '/rule1tool/trunk/htdocs/', 1223721847),
(824, 0.951154, '/rule1tool/trunk/htdocs/', 1223721935),
(825, 0.904916, '/rule1tool/trunk/htdocs/', 1223722168),
(826, 0.902692, '/rule1tool/trunk/htdocs/', 1223722310),
(827, 0.966238, '/rule1tool/trunk/htdocs/', 1223722357),
(828, 0.944474, '/rule1tool/trunk/htdocs/', 1223722382),
(829, 0.876031, '/rule1tool/trunk/htdocs/', 1223722420),
(830, 0.843914, '/rule1tool/trunk/htdocs/', 1223722892),
(831, 0.976225, '/rule1tool/trunk/htdocs/', 1223723524),
(832, 0.834347, '/rule1tool/trunk/htdocs/', 1223723538),
(833, 0.477137, '/rule1tool/trunk/htdocs/', 1223724137),
(834, 0.660099, '/rule1tool/trunk/htdocs/', 1223724310),
(835, 0.66611, '/rule1tool/trunk/htdocs/', 1223724344),
(836, 0.977325, '/rule1tool/trunk/htdocs/', 1223724350),
(837, 0.708682, '/rule1tool/trunk/htdocs/', 1223745548),
(838, 0.72474, '/rule1tool/trunk/htdocs/', 1223745864),
(839, 0.795479, '/rule1tool/trunk/htdocs/', 1223746233),
(840, 0.653287, '/rule1tool/trunk/htdocs/', 1223746245),
(841, 0.786183, '/rule1tool/trunk/htdocs/', 1223746959),
(842, 0.750512, '/rule1tool/trunk/htdocs/', 1223748106),
(843, 0.64763, '/rule1tool/trunk/htdocs/', 1223748129),
(844, 1.129177, '/rule1tool/trunk/htdocs/', 1223748234),
(845, 0.601565, '/rule1tool/trunk/htdocs/', 1223748280),
(846, 0.478852, '/rule1tool/trunk/htdocs/', 1223748607),
(847, 0.668403, '/rule1tool/trunk/htdocs/', 1223748641),
(848, 0.783463, '/rule1tool/trunk/htdocs/', 1223748775),
(849, 0.675732, '/rule1tool/trunk/htdocs/', 1223748816),
(850, 0.696285, '/rule1tool/trunk/htdocs/', 1223748845),
(851, 0.778129, '/rule1tool/trunk/htdocs/', 1223748912),
(852, 0.657462, '/rule1tool/trunk/htdocs/', 1223748945),
(853, 0.844413, '/rule1tool/trunk/htdocs/', 1223750203),
(854, 0.762255, '/rule1tool/trunk/htdocs/', 1223750891),
(855, 0.641251, '/rule1tool/trunk/htdocs/', 1223751136),
(856, 0.829767, '/rule1tool/trunk/htdocs/', 1223751288),
(857, 0.826327, '/rule1tool/trunk/htdocs/', 1223751307),
(858, 0.650806, '/rule1tool/trunk/htdocs/', 1223751317),
(859, 1.065233, '/rule1tool/trunk/htdocs/', 1223751975),
(860, 0.682587, '/rule1tool/trunk/htdocs/', 1223752195),
(861, 1.003004, '/rule1tool/trunk/htdocs/', 1223752621),
(862, 0.663875, '/rule1tool/trunk/htdocs/', 1223752669),
(863, 0.661433, '/rule1tool/trunk/htdocs/', 1223752929),
(864, 0.807466, '/rule1tool/trunk/htdocs/', 1223754587),
(865, 0.663864, '/rule1tool/trunk/htdocs/', 1223755921),
(866, 0.815482, '/rule1tool/trunk/htdocs/', 1223762187),
(867, 0.955914, '/rule1tool/trunk/htdocs/', 1223762614),
(868, 0.713141, '/rule1tool/trunk/htdocs/', 1223762622),
(869, 0.652254, '/rule1tool/trunk/htdocs/', 1223762651),
(870, 0.654865, '/rule1tool/trunk/htdocs/', 1223762687),
(871, 0.654797, '/rule1tool/trunk/htdocs/', 1223762713),
(872, 0.66061, '/rule1tool/trunk/htdocs/', 1223762755),
(873, 0.665576, '/rule1tool/trunk/htdocs/', 1223762790),
(874, 0.713276, '/rule1tool/trunk/htdocs/', 1223762862),
(875, 0.702264, '/rule1tool/trunk/htdocs/', 1223762908),
(876, 0.839596, '/rule1tool/trunk/htdocs/', 1223762954),
(877, 0.808179, '/rule1tool/trunk/htdocs/', 1223762975),
(878, 0.85219, '/rule1tool/trunk/htdocs/', 1223763007),
(879, 0.663813, '/rule1tool/trunk/htdocs/', 1223763022),
(880, 1.570756, '/rule1tool/trunk/htdocs/', 1223763593),
(881, 0.669939, '/rule1tool/trunk/htdocs/', 1223763622),
(882, 0.650317, '/rule1tool/trunk/htdocs/', 1223763869),
(883, 0.72963, '/rule1tool/trunk/htdocs/', 1223763891),
(884, 0.780316, '/rule1tool/trunk/htdocs/', 1223764430),
(885, 0.669732, '/rule1tool/trunk/htdocs/', 1223764541),
(886, 0.684064, '/rule1tool/trunk/htdocs/', 1223764602),
(887, 0.671618, '/rule1tool/trunk/htdocs/', 1223764850),
(888, 0.663429, '/rule1tool/trunk/htdocs/', 1223764870),
(889, 0.719707, '/rule1tool/trunk/htdocs/', 1223765018),
(890, 0.900706, '/rule1tool/trunk/htdocs/', 1223765211),
(891, 0.670576, '/rule1tool/trunk/htdocs/', 1223765300),
(892, 0.686047, '/rule1tool/trunk/htdocs/', 1223765321),
(893, 0.653086, '/rule1tool/trunk/htdocs/', 1223765374),
(894, 1.262748, '/rule1tool/trunk/htdocs/', 1223765938),
(895, 0.604778, '/rule1tool/trunk/htdocs/', 1223766299),
(896, 0.521177, '/rule1tool/trunk/htdocs/', 1223766327),
(897, 0.6604, '/rule1tool/trunk/htdocs/', 1223766363),
(898, 0.662222, '/rule1tool/trunk/htdocs/', 1223766478),
(899, 0.769195, '/rule1tool/trunk/htdocs/', 1223766561),
(900, 0.691126, '/rule1tool/trunk/htdocs/', 1223766650),
(901, 0.696366, '/rule1tool/trunk/htdocs/', 1223766747),
(902, 0.699179, '/rule1tool/trunk/htdocs/', 1223767719),
(903, 0.66665, '/rule1tool/trunk/htdocs/', 1223767835),
(904, 0.69473, '/rule1tool/trunk/htdocs/', 1223767867),
(905, 2.085187, '/rule1tool/trunk/htdocs/', 1223768183),
(906, 0.71263, '/rule1tool/trunk/htdocs/', 1223768659),
(907, 0.668385, '/rule1tool/trunk/htdocs/', 1223768707),
(908, 0.654741, '/rule1tool/trunk/htdocs/', 1223768763),
(909, 0.700485, '/rule1tool/trunk/htdocs/', 1223768931),
(910, 0.681726, '/rule1tool/trunk/htdocs/', 1223769084),
(911, 0.648508, '/rule1tool/trunk/htdocs/', 1223769182),
(912, 0.62114, '/rule1tool/trunk/htdocs/', 1223769306),
(913, 0.667641, '/rule1tool/trunk/htdocs/', 1223769335),
(914, 0.79044, '/rule1tool/trunk/htdocs/', 1223769419),
(915, 2.577, '/rule1tool/trunk/htdocs/', 1223801612),
(916, 3.665154, '/rule1tool/trunk/htdocs/', 1223801613),
(917, 1.615546, '/rule1tool/trunk/htdocs/', 1223801668),
(918, 0.815144, '/rule1tool/trunk/htdocs/', 1223801751),
(919, 0.742982, '/rule1tool/trunk/htdocs/', 1223801763),
(920, 0.897571, '/rule1tool/trunk/htdocs/', 1223801794),
(921, 1.566012, '/rule1tool/trunk/htdocs/', 1223802657),
(922, 0.812301, '/rule1tool/trunk/htdocs/', 1223802673),
(923, 0.775673, '/rule1tool/trunk/htdocs/', 1223802736),
(924, 0.819034, '/rule1tool/trunk/htdocs/', 1223802796),
(925, 0.843261, '/rule1tool/trunk/htdocs/', 1223804597),
(926, 0.830042, '/rule1tool/trunk/htdocs/', 1223804989),
(927, 0.669415, '/rule1tool/trunk/htdocs/', 1223805000),
(928, 0.881593, '/rule1tool/trunk/htdocs/', 1223805007),
(929, 0.898094, '/rule1tool/trunk/htdocs/', 1223805049),
(930, 0.662838, '/rule1tool/trunk/htdocs/', 1223805190),
(931, 0.702084, '/rule1tool/trunk/htdocs/', 1223805388),
(932, 0.632813, '/rule1tool/trunk/htdocs/', 1223805493),
(933, 0.641284, '/rule1tool/trunk/htdocs/', 1223805569),
(934, 0.650305, '/rule1tool/trunk/htdocs/', 1223805667),
(935, 0.694193, '/rule1tool/trunk/htdocs/', 1223805717),
(936, 0.688269, '/rule1tool/trunk/htdocs/', 1223805748),
(937, 0.691575, '/rule1tool/trunk/htdocs/', 1223805781),
(938, 0.698523, '/rule1tool/trunk/htdocs/', 1223806070),
(939, 0.682631, '/rule1tool/trunk/htdocs/', 1223806108),
(940, 0.874636, '/rule1tool/trunk/htdocs/', 1223806193),
(941, 0.836256, '/rule1tool/trunk/htdocs/', 1223806219),
(942, 0.863493, '/rule1tool/trunk/htdocs/', 1223807939),
(943, 3.741038, '/rule1tool/trunk/htdocs/', 1223808936),
(944, 0.722273, '/rule1tool/trunk/htdocs/', 1223810039),
(945, 1.004238, '/rule1tool/trunk/htdocs/', 1223813393),
(946, 0.986278, '/rule1tool/trunk/htdocs/', 1223813909),
(947, 1.030295, '/rule1tool/trunk/htdocs/', 1223814228),
(948, 0.870708, '/rule1tool/trunk/htdocs/', 1223815425),
(949, 0.825999, '/rule1tool/trunk/htdocs/', 1223816172),
(950, 0.768937, '/rule1tool/trunk/htdocs/', 1223816430),
(951, 0.831644, '/rule1tool/trunk/htdocs/', 1223817461),
(952, 0.874262, '/rule1tool/trunk/htdocs/', 1223817529),
(953, 1.081867, '/rule1tool/trunk/htdocs/', 1223818064),
(954, 0.942847, '/rule1tool/trunk/htdocs/', 1223818101),
(955, 1.012435, '/rule1tool/trunk/htdocs/', 1223818230),
(956, 0.787589, '/rule1tool/trunk/htdocs/de/index/index', 1223830308),
(957, 1.228522, '/rule1tool/trunk/htdocs/de/images/loadingAnimation.gif', 1223830310),
(958, 1.466174, '/rule1tool/trunk/htdocs/de/stocks/search?needle=apple', 1223830315),
(959, 0.196148, '/rule1tool/trunk/htdocs/de/images/loadingAnimation.gif', 1223830316),
(960, 0.249452, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1223830320),
(961, 0.193866, '/rule1tool/trunk/htdocs/de/images/loadingAnimation.gif', 1223830321),
(962, 1.072491, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1223830337),
(963, 0.235896, '/rule1tool/trunk/htdocs/de/error/notfound', 1223830339),
(964, 1.042363, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1223830595),
(965, 0.189264, '/rule1tool/trunk/htdocs/de/error/notfound', 1223830597),
(967, 0.191031, '/rule1tool/trunk/htdocs/de/error/notfound', 1223831821),
(969, 0.19271, '/rule1tool/trunk/htdocs/de/error/notfound', 1223831831),
(971, 0.206902, '/rule1tool/trunk/htdocs/de/error/notfound', 1223831976),
(972, 0.250181, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1223832444),
(973, 0.209784, '/rule1tool/trunk/htdocs/de/error/notfound', 1223832446),
(974, 0.322125, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1223832602),
(975, 0.192726, '/rule1tool/trunk/htdocs/de/error/notfound', 1223832604),
(976, 0.279299, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1223832664),
(977, 0.190015, '/rule1tool/trunk/htdocs/de/error/notfound', 1223832666),
(978, 0.278555, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1223833077),
(979, 0.19026, '/rule1tool/trunk/htdocs/de/error/notfound', 1223833079),
(980, 0.309999, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1223834224),
(981, 0.190332, '/rule1tool/trunk/htdocs/de/error/notfound', 1223834226),
(982, 0.324429, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1223834259),
(983, 0.191926, '/rule1tool/trunk/htdocs/de/error/notfound', 1223834261),
(984, 0.299488, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1223834452),
(985, 0.192748, '/rule1tool/trunk/htdocs/de/error/notfound', 1223834454),
(986, 0.324511, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1223834513),
(987, 0.189755, '/rule1tool/trunk/htdocs/de/error/notfound', 1223834515),
(988, 0.923611, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1223834601),
(989, 0.196842, '/rule1tool/trunk/htdocs/de/error/notfound', 1223834603),
(990, 0.716303, '/rule1tool/trunk/htdocs/de/analysis/create', 1224086422),
(991, 0.188848, '/rule1tool/trunk/htdocs/de/images/loadingAnimation.gif', 1224086423),
(992, 0.248298, '/rule1tool/trunk/htdocs/de/error/notfound', 1224086428),
(993, 0.415445, '/rule1tool/trunk/htdocs/de/error/notfound', 1224086430),
(994, 0.186921, '/rule1tool/trunk/htdocs/de/error/notfound', 1224086453),
(995, 0.514319, '/rule1tool/trunk/htdocs/de/error/notfound', 1224086469),
(996, 0.18736, '/rule1tool/trunk/htdocs/de/error/notfound', 1224086471),
(997, 0.191845, '/rule1tool/trunk/htdocs/de/error/notfound', 1224086564),
(998, 0.284056, '/rule1tool/trunk/htdocs/de/error/notfound', 1224086566),
(999, 1.438882, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1224086570),
(1000, 0.186061, '/rule1tool/trunk/htdocs/de/error/notfound', 1224086575),
(1001, 0.188553, '/rule1tool/trunk/htdocs/de/error/notfound', 1224086577),
(1002, 0.181049, '/rule1tool/trunk/htdocs/de/analysis/create', 1224086589),
(1003, 0.821811, '/rule1tool/trunk/htdocs/de/error/notfound', 1224086591),
(1004, 0.873091, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224086599),
(1005, 0.210177, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224086600),
(1006, 0.687311, '/rule1tool/trunk/htdocs/de/analysis/create/CID/2', 1224094871),
(1007, 0.188946, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224094872),
(1008, 0.734002, '/rule1tool/trunk/htdocs/de/analysis/create/CID/4', 1224094877),
(1009, 0.179604, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224094878),
(1010, 0.644776, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224094880),
(1011, 0.184666, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224094882),
(1012, 0.910805, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224094935),
(1013, 0.218103, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224094937),
(1014, 0.89159, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224095002),
(1015, 0.184085, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224095004),
(1016, 0.730532, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224095129),
(1017, 0.179236, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224095131),
(1018, 0.967677, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224095485),
(1019, 0.188047, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224095487),
(1020, 1.160249, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224095825),
(1021, 0.18812, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224095826),
(1022, 1.330869, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224096425),
(1023, 0.18278, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224096426),
(1024, 1.074054, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224096678),
(1025, 0.860926, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224096679),
(1026, 1.132204, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224096872),
(1027, 0.200617, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224096873),
(1028, 1.179514, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224096934),
(1029, 0.186668, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224096935),
(1030, 1.154615, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224096967),
(1031, 0.187468, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224096968),
(1032, 1.17857, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224135861),
(1033, 0.317096, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224135865),
(1034, 0.933539, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224135869),
(1035, 0.669433, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224135871),
(1036, 0.242934, '/rule1tool/trunk/htdocs/de/analysis/edit/CID/1', 1224135882),
(1037, 0.203314, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224135884),
(1038, 0.182822, '/rule1tool/trunk/htdocs/de/analysis/edit/CID/1', 1224135969),
(1039, 0.227323, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224135971),
(1040, 0.178548, '/rule1tool/trunk/htdocs/de/analysis/edit/CID/1', 1224135998),
(1041, 0.182281, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224135999),
(1042, 0.705927, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224136006),
(1043, 0.211682, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224136007),
(1044, 0.667425, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224167224),
(1045, 0.19056, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224167225),
(1046, 0.905812, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224167260),
(1047, 0.182736, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224167261),
(1048, 0.603234, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224173216),
(1049, 0.293887, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224173218),
(1050, 0.976216, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224177738),
(1051, 0.283911, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224177740),
(1052, 1.00353, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224177929),
(1053, 0.206989, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224177931),
(1054, 0.929266, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224177965),
(1055, 0.233578, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224177967),
(1056, 0.686007, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224178095),
(1057, 0.199395, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224178096),
(1058, 0.880391, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224178104),
(1059, 0.223095, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224178105),
(1060, 0.798305, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224178124),
(1061, 0.226113, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224178126),
(1062, 0.932795, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224178136),
(1063, 0.363007, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224178137),
(1064, 0.810504, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224178143),
(1065, 0.22313, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224178145),
(1066, 0.85083, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224178154),
(1067, 0.206007, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224178155),
(1068, 0.920917, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224178358),
(1069, 0.230261, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224178359),
(1070, 0.833004, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224178366),
(1071, 0.275729, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224178367),
(1072, 0.791055, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224178373),
(1073, 0.181073, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224178374),
(1074, 0.757158, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224178384),
(1075, 0.444604, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224178386),
(1076, 2.640501, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224180133),
(1077, 3.769493, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224180135),
(1078, 0.460164, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224180139),
(1079, 0.327497, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224180140),
(1080, 0.765412, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224180244),
(1081, 0.222245, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224180246),
(1082, 1.240269, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224180428),
(1083, 0.197635, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224180429),
(1084, 0.79786, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224180496),
(1085, 0.226536, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224180498),
(1086, 0.82082, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224180508),
(1087, 0.778335, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224181226),
(1088, 0.182487, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224181227),
(1089, 0.785661, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224183044),
(1090, 0.19578, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224183046),
(1091, 0.710554, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224183167),
(1092, 0.220151, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224183168),
(1093, 0.763827, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224183712),
(1094, 0.181049, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224183714),
(1095, 1.113777, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224184617),
(1096, 0.266351, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224184619),
(1097, 0.866409, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224184680),
(1098, 0.198829, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224184682),
(1099, 1.005688, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224185743),
(1100, 0.186352, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224185745),
(1101, 1.502586, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224186006),
(1102, 0.268451, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224186008),
(1103, 1.670071, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224186377),
(1104, 0.18257, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224186378),
(1105, 1.358631, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224187621),
(1106, 0.184924, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224187623),
(1107, 1.0097, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224187675),
(1108, 0.206858, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224187677),
(1109, 1.026068, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224187805),
(1110, 0.24797, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224187806),
(1111, 0.820854, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224187898),
(1112, 0.214219, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224187900),
(1113, 0.826698, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224187915),
(1114, 0.183941, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224187916),
(1115, 0.892267, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224188131),
(1116, 0.197853, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224188133),
(1117, 1.263831, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224219765),
(1118, 1.892944, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224219765),
(1119, 0.692774, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224219773),
(1120, 0.399341, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224219773),
(1121, 3.059693, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224219785),
(1122, 0.809094, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224219788),
(1123, 0.837873, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224220068),
(1124, 0.184434, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224220070),
(1125, 0.842205, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224220150),
(1126, 0.179569, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224220151),
(1127, 0.839812, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224220204),
(1128, 0.219671, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224220205),
(1129, 0.641454, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224220221),
(1130, 0.196749, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224220222),
(1131, 1.444076, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224220281),
(1132, 0.178021, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224220283),
(1133, 1.620241, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224220309),
(1134, 0.180364, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224220311),
(1135, 0.801639, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224220350),
(1136, 0.212749, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224220352),
(1137, 0.83184, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224220375),
(1138, 0.817928, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224220377),
(1139, 0.223781, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224220378),
(1140, 0.990256, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224220412),
(1141, 0.183468, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224220414),
(1142, 1.25758, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224220443),
(1143, 0.22655, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224220444),
(1144, 1.470496, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224220582),
(1145, 0.225186, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224220583),
(1146, 0.673609, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224220704),
(1147, 0.22546, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224220705),
(1148, 0.77501, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224220724),
(1149, 0.25673, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224220726),
(1150, 0.805283, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224220796),
(1151, 0.196606, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224220798),
(1152, 0.847659, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224220811),
(1153, 0.178435, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224220812),
(1154, 0.675611, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224220847),
(1155, 0.188575, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224220849),
(1156, 0.810321, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224220866),
(1157, 0.193999, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224220868),
(1158, 0.654556, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224220880),
(1159, 0.177965, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224220882),
(1160, 0.876471, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224220925),
(1161, 0.179204, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224220926),
(1162, 1.092086, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224221019),
(1163, 0.177969, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224221020),
(1164, 1.177413, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224221087),
(1165, 0.183385, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224221088),
(1166, 0.861743, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224221240),
(1167, 0.192022, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224221242),
(1168, 0.640481, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224221312),
(1169, 0.468039, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224221314),
(1170, 0.691055, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224221325),
(1171, 0.18123, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224221326),
(1172, 0.892093, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224221330),
(1173, 0.180223, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224221332),
(1174, 0.892949, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224232029),
(1175, 0.19158, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224232030),
(1176, 0.827312, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224232420),
(1177, 0.191825, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224232422),
(1178, 0.677483, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224246451),
(1179, 0.209743, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224246452),
(1180, 1.098952, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224246511),
(1181, 0.181126, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224246512),
(1182, 1.092166, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224246519),
(1183, 0.191324, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224246521),
(1184, 0.818545, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224246545),
(1185, 0.184342, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224246546),
(1186, 0.81571, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224246563),
(1187, 0.18487, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224246565),
(1188, 1.094651, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224246577),
(1189, 0.183583, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224246579),
(1190, 0.798207, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224246604),
(1191, 0.191784, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224246606),
(1192, 0.836032, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224246619),
(1193, 0.188655, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224246621),
(1194, 0.802529, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224246699),
(1195, 0.233181, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224246701),
(1196, 0.955232, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224246815),
(1197, 0.196644, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224246816),
(1198, 0.824397, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224247043),
(1199, 0.182407, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224247045),
(1200, 1.074845, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224247068),
(1201, 0.18615, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224247069),
(1202, 0.777737, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224247074),
(1203, 0.179592, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224247075),
(1204, 0.825641, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224247392),
(1205, 0.186304, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224247394),
(1206, 0.732872, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224247685),
(1207, 0.179469, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224247686),
(1208, 0.751135, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224247865),
(1209, 0.808182, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224247867),
(1210, 1.08338, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224247872),
(1211, 0.18601, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224247874),
(1212, 0.780001, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224247884),
(1213, 0.18571, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224247886),
(1214, 1.154263, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224247890),
(1215, 0.18948, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224247891),
(1216, 0.716234, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224247913),
(1217, 0.196169, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224247914),
(1218, 1.01551, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224247919),
(1219, 0.20852, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224247920),
(1220, 1.261843, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224326256),
(1221, 2.013342, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224326256),
(1222, 0.50065, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224326261),
(1223, 0.308255, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224326261),
(1224, 0.212621, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224327021),
(1225, 0.220641, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224327022),
(1226, 1.407893, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224327025),
(1227, 0.207129, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224327027),
(1228, 2.645007, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1', 1224327081),
(1229, 3.221301, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224327083),
(1230, 0.362341, '/rule1tool/trunk/htdocs/de/analysis/edit/images/loadingAnimation.gif', 1224327086),
(1231, 0.180341, '/rule1tool/trunk/htdocs/de/analysis/create/images/loadingAnimation.gif', 1224327086),
(1232, 0.320292, '/rule1tool/trunk/htdocs/', 1224328169),
(1233, 1.112385, '/rule1tool/trunk/htdocs/de/stocks/index', 1224328175),
(1234, 0.187137, '/rule1tool/trunk/htdocs/de/images/loadingAnimation.gif', 1224328176),
(1235, 0.230691, '/rule1tool/trunk/htdocs/de/stocks/index', 1224328257),
(1236, 0.234456, '/rule1tool/trunk/htdocs/de/error/notfound', 1224328260),
(1237, 0.384004, '/rule1tool/trunk/htdocs/de/index/index', 1224329505),
(1238, 0.202102, '/rule1tool/trunk/htdocs/de/error/notfound', 1224329508),
(1239, 14.50877, '/rule1tool/trunk/htdocs/de/stocks/search?needle=apple', 1224330967),
(1240, 0.19995, '/rule1tool/trunk/htdocs/de/error/notfound', 1224330969),
(1241, 0.881165, '/rule1tool/trunk/htdocs/de/stock/US0378331005', 1224330980),
(1242, 0.255852, '/rule1tool/trunk/htdocs/de/error/notfound', 1224330982),
(1243, 0.559891, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224522130),
(1244, 0.712577, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224522135),
(1245, 0.365699, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224522197),
(1246, 0.326131, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224522229),
(1247, 0.309593, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224522305),
(1248, 0.43512, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224522521),
(1249, 0.294757, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224522585),
(1250, 0.305466, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224522607),
(1251, 0.305528, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224522634),
(1252, 0.332076, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224522867),
(1253, 0.373464, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224524151),
(1254, 0.258925, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224524201),
(1255, 0.282317, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224529369),
(1256, 1.231494, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224529392),
(1257, 1.091277, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1/NEW/1/module', 1224529446),
(1258, 0.359754, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224529460),
(1259, 0.346703, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224529969),
(1260, 0.307533, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530010),
(1261, 0.300131, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530099),
(1262, 0.29627, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530162),
(1263, 0.330662, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530322),
(1264, 0.2996, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530414),
(1265, 0.320223, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530458),
(1266, 0.3574, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530570),
(1267, 0.372005, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530591),
(1268, 0.38246, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530632),
(1269, 0.363359, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530642),
(1270, 0.363183, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530651),
(1271, 0.383844, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530661),
(1272, 0.382146, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530731),
(1273, 0.39417, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224530732),
(1274, 0.713243, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224567143),
(1275, 0.759011, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224567150),
(1276, 0.388069, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224567190),
(1277, 0.380846, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224567309),
(1278, 0.374195, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224567351),
(1279, 0.879293, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224567376),
(1280, 0.386844, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224567414),
(1281, 0.412436, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224567511),
(1282, 0.424458, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224590379),
(1283, 0.38351, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224590399),
(1284, 0.408977, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224590508),
(1285, 0.362955, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224590574),
(1286, 0.450535, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224590576),
(1287, 0.366349, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224590578),
(1288, 0.382454, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224590582),
(1289, 0.430615, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224590598),
(1290, 0.366126, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224590632),
(1291, 1.427633, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/1/NEW/1/module', 1224590642),
(1292, 0.699046, '/rule1tool/trunk/htdocs/de/analysis/create/CID/1', 1224590647),
(1293, 1.07959, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/2/NEW/1/module', 1224590689),
(1294, 0.480364, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224590697),
(1295, 0.38995, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224590708),
(1296, 0.407538, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224590724),
(1297, 0.436965, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224590730),
(1298, 0.436085, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224590736),
(1299, 0.388959, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224590742),
(1300, 0.432053, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224590935),
(1301, 0.432076, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224590941),
(1302, 0.398883, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=1', 1224590955),
(1303, 0.440649, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=1', 1224591010),
(1304, 0.389447, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=1', 1224591089),
(1305, 0.434615, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224591096),
(1306, 0.390643, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224591107),
(1307, 0.454953, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224595547),
(1308, 0.546349, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224595620),
(1309, 0.439842, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224595641),
(1310, 0.458706, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224598073),
(1311, 2.488197, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/2/NEW/1/module', 1224653849),
(1312, 2.910587, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224653849),
(1313, 0.598042, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224653855),
(1314, 0.448149, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224654397),
(1315, 0.408747, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224654419),
(1316, 0.405266, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224654543),
(1317, 0.441305, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224654840),
(1318, 0.712706, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224656236),
(1319, 1.245641, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/2/NEW/1/module', 1224700613),
(1320, 1.613887, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224700613),
(1321, 0.678534, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224700624),
(1322, 0.435725, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224701077),
(1323, 0.266855, '/rule1tool/trunk/htdocs/', 1224701088),
(1324, 0.17956, '/rule1tool/trunk/htdocs/de/auth/login', 1224701091),
(1325, 0.175457, '/rule1tool/trunk/htdocs/de/auth/login', 1224701096),
(1326, 0.172417, '/rule1tool/trunk/htdocs/de/auth/login', 1224701099),
(1327, 0.185642, '/rule1tool/trunk/htdocs/de/index/index', 1224701103),
(1328, 0.188709, '/rule1tool/trunk/htdocs/?KeepThis=true&', 1224701129),
(1329, 0.26845, '/rule1tool/trunk/htdocs/de/auth/login', 1224701154),
(1330, 0.253633, '/rule1tool/trunk/htdocs/de/auth/login', 1224701155),
(1331, 0.181174, '/rule1tool/trunk/htdocs/de/auth/login', 1224701155),
(1332, 0.183196, '/rule1tool/trunk/htdocs/', 1224701157),
(1333, 0.174999, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224701158),
(1334, 0.170964, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224701161),
(1335, 0.17767, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1?AID=2', 1224701167),
(1336, 0.186057, '/rule1tool/trunk/htdocs/de/index/index', 1224701174),
(1337, 0.181334, '/rule1tool/trunk/htdocs/de/auth/login', 1224701180),
(1338, 0.172803, '/rule1tool/trunk/htdocs/de/auth/login', 1224701185),
(1339, 0.208322, '/rule1tool/trunk/htdocs/de/index/index', 1224701189),
(1340, 0.286442, '/rule1tool/trunk/htdocs/de/stocks/index', 1224701192),
(1341, 0.360035, '/rule1tool/trunk/htdocs/de/index/index', 1224701324),
(1342, 0.400274, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224701340),
(1343, 0.450735, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224701566),
(1344, 0.421854, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224701673),
(1345, 0.420695, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224701734),
(1346, 0.496961, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224705159),
(1347, 0.786057, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224705881),
(1348, 0.71615, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224705920),
(1349, 0.725226, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224746774),
(1350, 0.276491, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224749454),
(1351, 1.471131, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224749460),
(1352, 1.274805, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224749490),
(1353, 3.319036, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/2/NEW/1/module', 1224749493),
(1354, 0.705669, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224749501),
(1355, 0.842252, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224750029),
(1356, 0.824602, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224754505),
(1357, 0.913255, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224754532),
(1358, 0.296892, '/rule1tool/trunk/htdocs/', 1224754538),
(1359, 0.181802, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224754546),
(1360, 0.719605, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224754551),
(1361, 0.727173, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224754565),
(1362, 0.661633, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224754567),
(1363, 0.188562, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224754603),
(1364, 0.655716, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224754656),
(1365, 0.196967, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224754782),
(1366, 0.776112, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224788588),
(1367, 0.726126, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224788659),
(1368, 0.915377, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224789078),
(1369, 0.756787, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224789204),
(1370, 0.747283, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224826104),
(1371, 0.914197, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1224826496),
(1372, 1.545268, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/2/NEW/1/module', 1225050691),
(1373, 1.563141, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225050691),
(1374, 3.5018, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225050704),
(1375, 1.492734, '/rule1tool/trunk/htdocs/de/analysis/show', 1225050718),
(1376, 1.392101, '/rule1tool/trunk/htdocs/de/analysis/show', 1225050780),
(1377, 1.49485, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225050811),
(1378, 3.512419, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225050968),
(1379, 2.136292, '/rule1tool/trunk/htdocs/de/analysis/show', 1225050987),
(1380, 0.84552, '/rule1tool/trunk/htdocs/de/analysis/show', 1225051496),
(1381, 1.209144, '/rule1tool/trunk/htdocs/de/analysis/show', 1225051501),
(1382, 0.757628, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225051510),
(1383, 0.883804, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225052719),
(1384, 0.891744, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225052726),
(1385, 1.262262, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225088793),
(1386, 1.268055, '/rule1tool/trunk/htdocs/de/analysis/edit/AID/2/NEW/1/module', 1225088793),
(1387, 2.217293, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225088806),
(1388, 0.862959, '/rule1tool/trunk/htdocs/de/analysis/show', 1225088918),
(1389, 0.435881, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225089177),
(1390, 0.397353, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225089186),
(1391, 0.764944, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225089255),
(1392, 0.766332, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225089751),
(1393, 0.798677, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225090013),
(1394, 0.398355, '/rule1tool/trunk/htdocs/de/analysis/show', 1225090019),
(1395, 0.405656, '/rule1tool/trunk/htdocs/de/analysis/show', 1225090079),
(1396, 0.594089, '/rule1tool/trunk/htdocs/de/analysis/show', 1225090153),
(1397, 0.893955, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225118883),
(1398, 0.82813, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225120756),
(1399, 0.405652, '/rule1tool/trunk/htdocs/de/analysis/show', 1225120763),
(1400, 0.420003, '/rule1tool/trunk/htdocs/de/analysis/show', 1225120781),
(1401, 0.774985, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225120846),
(1402, 0.422477, '/rule1tool/trunk/htdocs/de/analysis/show', 1225120854),
(1403, 0.786045, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225121251),
(1404, 0.755154, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225121289),
(1405, 0.422665, '/rule1tool/trunk/htdocs/de/analysis/show', 1225121294),
(1406, 0.400095, '/rule1tool/trunk/htdocs/de/analysis/show', 1225121299),
(1407, 0.397583, '/rule1tool/trunk/htdocs/de/analysis/show', 1225121305),
(1408, 0.408097, '/rule1tool/trunk/htdocs/de/analysis/show', 1225121520),
(1409, 0.761633, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225121530),
(1410, 0.441249, '/rule1tool/trunk/htdocs/de/analysis/show', 1225121539),
(1411, 0.408947, '/rule1tool/trunk/htdocs/de/analysis/show', 1225121551),
(1412, 0.435165, '/rule1tool/trunk/htdocs/de/analysis/show', 1225121563),
(1413, 0.994579, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225125959),
(1414, 0.841557, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126123),
(1415, 0.757088, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126174),
(1416, 0.806374, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126207),
(1417, 0.778162, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126247),
(1418, 0.780126, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126325),
(1419, 0.895042, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126492),
(1420, 1.375584, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126541),
(1421, 0.764255, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126585),
(1422, 0.788594, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126617),
(1423, 1.066414, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126663),
(1424, 0.784887, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126879),
(1425, 0.782172, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126917),
(1426, 0.87164, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225126979),
(1427, 0.832195, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225127011),
(1428, 0.769189, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225127043),
(1429, 0.787852, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225127072),
(1430, 0.786151, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225141958),
(1431, 0.799797, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225142115),
(1432, 0.625339, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225211725),
(1433, 0.885136, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225211754),
(1434, 0.803844, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225211779),
(1435, 0.784389, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225211846),
(1436, 0.811739, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225212403),
(1437, 0.832704, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225212465),
(1438, 1.566268, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225271065),
(1439, 1.474717, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225271080),
(1440, 0.824573, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225271981),
(1441, 0.813584, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225272028),
(1442, 0.882989, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225272294),
(1443, 0.778513, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225272376),
(1444, 0.840778, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225272378),
(1445, 0.814574, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225275645),
(1446, 0.84909, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225276004),
(1447, 0.861656, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225276193),
(1448, 0.828574, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225276269),
(1449, 0.84258, '/rule1tool/trunk/htdocs/de/analysis/show', 1225279520),
(1450, 0.412466, '/rule1tool/trunk/htdocs/de/analysis/show', 1225279528),
(1451, 1.78394, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225281192),
(1452, 1.338068, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225281234),
(1453, 1.379361, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225281291),
(1454, 1.435047, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225281308),
(1455, 1.522203, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225284953),
(1456, 1.345119, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225285014),
(1457, 1.414234, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225285040),
(1458, 2.100308, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225285050),
(1459, 0.389557, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225285050),
(1460, 0.283895, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225285056);
INSERT INTO `logprofiler` (`id`, `time_execution`, `uri`, `date_add`) VALUES
(1461, 1.356423, '/rule1tool/trunk/htdocs/de/analysis/show/CID/1', 1225285065);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `new_companies`
--

CREATE TABLE IF NOT EXISTS `new_companies` (
  `company_id` int(10) unsigned NOT NULL,
  `date_add` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `new_companies`
--

INSERT INTO `new_companies` (`company_id`, `date_add`) VALUES
(1, 1224330979);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `quotes`
--

CREATE TABLE IF NOT EXISTS `quotes` (
  `id` int(10) NOT NULL auto_increment,
  `author` char(255) collate utf8_unicode_ci default NULL,
  `quote` text collate utf8_unicode_ci,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `lang` char(2) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Daten für Tabelle `quotes`
--

INSERT INTO `quotes` (`id`, `author`, `quote`, `date`, `lang`) VALUES
(1, 'Napoleon Hill', 'Jede Leistung und jeder Erfolg wurzeln in einer Idee.', '2008-06-07 00:55:27', 'de'),
(2, 'Albert Schweitzer', 'Success is not the key to happiness. Happiness is the key to success. If you love what you are doing, you will be successful.', '2008-06-07 00:56:13', 'en'),
(3, 'Benjamin Graham', 'Geduld ist die oberste Tugend des Investors.', '2008-06-07 00:56:45', 'de'),
(4, 'Andr√© Kostolany', 'Buy on bad news, sell on good news.', '2008-06-07 00:58:22', 'en');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `registrations`
--

CREATE TABLE IF NOT EXISTS `registrations` (
  `user_id` int(10) unsigned NOT NULL,
  `ip` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `registrations`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `sytemtype` varchar(10) collate utf8_unicode_ci NOT NULL,
  `name` varchar(35) collate utf8_unicode_ci NOT NULL,
  `value` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`sytemtype`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `settings`
--

INSERT INTO `settings` (`sytemtype`, `name`, `value`) VALUES
('dev', 'status', 'OFFLINE'),
('live', 'status', 'OFFLINE'),
('local', 'status', 'ONLINE');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stockexchanges`
--

CREATE TABLE IF NOT EXISTS `stockexchanges` (
  `market_id` tinyint(4) NOT NULL auto_increment,
  `countrycode` varchar(2) collate utf8_unicode_ci NOT NULL,
  `symbolextension` varchar(2) collate utf8_unicode_ci default NULL,
  `name` varchar(55) collate utf8_unicode_ci NOT NULL,
  `time_start` tinyint(4) unsigned zerofill NOT NULL,
  `time_end` smallint(4) unsigned zerofill NOT NULL,
  `currency` varchar(5) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`market_id`),
  KEY `countrycode` (`countrycode`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Daten für Tabelle `stockexchanges`
--

INSERT INTO `stockexchanges` (`market_id`, `countrycode`, `symbolextension`, `name`, `time_start`, `time_end`, `currency`) VALUES
(1, 'DE', 'DE', 'Xetra', 0000, 1800, 'EUR'),
(3, 'US', NULL, 'NASDAQ', 0000, 2200, 'USD');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stockquotes_eod`
--

CREATE TABLE IF NOT EXISTS `stockquotes_eod` (
  `company_id` int(10) unsigned NOT NULL,
  `market_id` tinyint(4) NOT NULL,
  `open` double unsigned NOT NULL,
  `close` double unsigned NOT NULL,
  `high` double unsigned NOT NULL,
  `low` double unsigned NOT NULL,
  `volume` double unsigned NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`company_id`,`market_id`,`date`),
  KEY `market_id` (`market_id`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `stockquotes_eod`
--

INSERT INTO `stockquotes_eod` (`company_id`, `market_id`, `open`, `close`, `high`, `low`, `volume`, `date`) VALUES
(1, 1, 118.67, 115.98, 119.55, 114.05, 16200, '2007-10-15'),
(1, 1, 117.5, 119.23, 119.23, 116.16, 7200, '2007-10-16'),
(1, 1, 121, 120.8, 122.5, 120.36, 17600, '2007-10-17'),
(1, 1, 121.95, 120.69, 121.95, 119.58, 12600, '2007-10-18'),
(1, 1, 121.3, 120.7, 122.65, 119.53, 13700, '2007-10-19'),
(1, 1, 118.11, 122.48, 123.22, 117.7, 20900, '2007-10-22'),
(1, 1, 131.13, 130.15, 133.5, 127.05, 68400, '2007-10-23'),
(1, 1, 129.99, 127.51, 131, 126.32, 34200, '2007-10-24'),
(1, 1, 130.35, 129.47, 132.58, 128, 22200, '2007-10-25'),
(1, 1, 128.7, 128.16, 129.21, 127.53, 19300, '2007-10-26'),
(1, 1, 129.21, 128.45, 129.75, 128.45, 15600, '2007-10-29'),
(1, 1, 128.35, 129.85, 130.25, 127.7, 13700, '2007-10-30'),
(1, 1, 129.8, 130.6, 130.92, 129.55, 11700, '2007-10-31'),
(1, 1, 131.95, 130.24, 131.95, 129.69, 11100, '2007-11-01'),
(1, 1, 129.7, 128.44, 131, 126.88, 31500, '2007-11-02'),
(1, 1, 128.71, 130.18, 130.18, 127.49, 14100, '2007-11-05'),
(1, 1, 128.9, 127.93, 129.61, 127.43, 12800, '2007-11-06'),
(1, 1, 130.01, 130.5, 131.2, 128, 28600, '2007-11-07'),
(1, 1, 126.49, 124.32, 128.41, 123.23, 38700, '2007-11-08'),
(1, 1, 120.6, 116.73, 122.95, 112.67, 120500, '2007-11-09'),
(1, 1, 112.2, 109.65, 115.15, 108.33, 80100, '2007-11-12'),
(1, 1, 105, 115.86, 115.86, 104.1, 95000, '2007-11-13'),
(1, 1, 117.3, 118.19, 120.4, 116.51, 74700, '2007-11-14'),
(1, 1, 113.75, 114.98, 115.72, 111.8, 43800, '2007-11-15'),
(1, 1, 112.49, 111.55, 114.07, 108.93, 46600, '2007-11-16'),
(1, 1, 114, 112.35, 114.56, 111.75, 23000, '2007-11-19'),
(1, 1, 112, 115.72, 116.22, 111.5, 33500, '2007-11-20'),
(1, 1, 113.59, 111.85, 113.59, 111.26, 27700, '2007-11-21'),
(1, 1, 113.95, 114.4, 114.4, 113.5, 6000, '2007-11-22'),
(1, 1, 114.19, 115.06, 116.29, 114, 9800, '2007-11-23'),
(1, 1, 116.89, 117.1, 118.9, 116.44, 14900, '2007-11-26'),
(1, 1, 117.8, 117.8, 118.09, 112.9, 42000, '2007-11-27'),
(1, 1, 118.7, 120.28, 120.8, 118.12, 21000, '2007-11-28'),
(1, 1, 121.85, 124.53, 124.75, 121.41, 33800, '2007-11-29'),
(1, 1, 125.26, 123.52, 127.4, 123, 36400, '2007-11-30'),
(1, 1, 123.9, 124.5, 125.07, 121.89, 24600, '2007-12-03'),
(1, 1, 122.3, 122.17, 122.68, 119.5, 25900, '2007-12-04'),
(1, 1, 123, 126.31, 126.31, 122.7, 12100, '2007-12-05'),
(1, 1, 128.08, 128.48, 129.4, 127.16, 27900, '2007-12-06'),
(1, 1, 129.4, 129.41, 130.42, 128.3, 22100, '2007-12-07'),
(1, 1, 131.51, 131.89, 132.98, 131, 24000, '2007-12-10'),
(1, 1, 132, 133.58, 133.69, 131.7, 13200, '2007-12-11'),
(1, 1, 128.5, 131.25, 132.34, 128.11, 36500, '2007-12-12'),
(1, 1, 129.49, 129.59, 130.85, 128.14, 26500, '2007-12-13'),
(1, 1, 131.11, 133.17, 133.74, 130.66, 22500, '2007-12-14'),
(1, 1, 132.35, 129.87, 133.78, 129.87, 27000, '2007-12-17'),
(1, 1, 128.98, 126.44, 130.16, 125.89, 32100, '2007-12-18'),
(1, 1, 127.79, 126.01, 127.86, 126.01, 20200, '2007-12-19'),
(1, 1, 127.33, 128.33, 129.36, 127.33, 13900, '2007-12-20'),
(1, 1, 131.3, 133.47, 133.96, 130.05, 12600, '2007-12-21'),
(1, 1, 133.47, 133.47, 133.47, 133.47, 0, '2007-12-24'),
(1, 1, 133.47, 133.47, 133.47, 133.47, 0, '2007-12-25'),
(1, 1, 133.47, 133.47, 133.47, 133.47, 0, '2007-12-26'),
(1, 1, 137.25, 138.34, 139.3, 133.3, 16300, '2007-12-27'),
(1, 1, 136.6, 137.03, 137.03, 135.71, 4700, '2007-12-28'),
(1, 1, 137.03, 137.03, 137.03, 137.03, 0, '2007-12-31'),
(1, 1, 137.03, 137.03, 137.03, 137.03, 0, '2008-01-01'),
(1, 1, 135.8, 132.16, 136.5, 132.16, 18900, '2008-01-02'),
(1, 1, 132.66, 132.43, 133.46, 131.03, 13100, '2008-01-03'),
(1, 1, 133.2, 128.31, 134.58, 127.3, 43800, '2008-01-04'),
(1, 1, 124, 119.25, 124.88, 116, 77600, '2008-01-07'),
(1, 1, 121.39, 121.55, 123.66, 121, 44200, '2008-01-08'),
(1, 1, 117.74, 116.52, 118.98, 115.3, 58100, '2008-01-09'),
(1, 1, 122.7, 119.9, 123, 118.01, 30000, '2008-01-10'),
(1, 1, 119.74, 119.15, 120.1, 118, 24500, '2008-01-11'),
(1, 1, 117.01, 119.23, 119.66, 116.5, 26300, '2008-01-14'),
(1, 1, 120.39, 118.33, 121.44, 117.5, 36100, '2008-01-15'),
(1, 1, 109.35, 109.31, 114, 106.51, 101200, '2008-01-16'),
(1, 1, 110, 109.31, 111.55, 108.09, 39200, '2008-01-17'),
(1, 1, 111.84, 110.98, 112.99, 110.35, 18000, '2008-01-18'),
(1, 1, 110.29, 104.49, 110.29, 103.5, 60700, '2008-01-21'),
(1, 1, 94, 108.83, 110.19, 92.7, 128900, '2008-01-22'),
(1, 1, 95.77, 90, 98.07, 90, 100900, '2008-01-23'),
(1, 1, 95.71, 91.64, 97.43, 90.02, 83300, '2008-01-24'),
(1, 1, 93.51, 90.7, 94.93, 89.9, 62400, '2008-01-25'),
(1, 1, 87.48, 89.3, 89.4, 85.68, 53400, '2008-01-28'),
(1, 1, 88, 89.38, 89.99, 87.7, 32400, '2008-01-29'),
(1, 1, 88.98, 89.46, 89.46, 88, 17100, '2008-01-30'),
(1, 1, 88.95, 89.83, 89.83, 86.68, 25300, '2008-01-31'),
(1, 1, 91.15, 89.89, 92.6, 89.39, 40700, '2008-02-01'),
(1, 1, 90.73, 90.95, 91.65, 90.23, 14900, '2008-02-04'),
(1, 1, 89.83, 90.14, 91.12, 88.76, 14800, '2008-02-05'),
(1, 1, 88, 87.99, 90.1, 87.75, 25000, '2008-02-06'),
(1, 1, 82.64, 82.71, 83.7, 80.9, 39600, '2008-02-07'),
(1, 1, 84.44, 86.02, 86.5, 82.71, 23400, '2008-02-08'),
(1, 1, 86.34, 88.47, 88.95, 86, 13700, '2008-02-11'),
(1, 1, 89.94, 88.36, 90.41, 87.91, 25200, '2008-02-12'),
(1, 1, 86.05, 86.8, 87.62, 85.8, 23000, '2008-02-13'),
(1, 1, 89.79, 87.66, 89.8, 87.46, 14800, '2008-02-14'),
(1, 1, 87.3, 85.25, 87.79, 85.25, 8600, '2008-02-15'),
(1, 1, 85.24, 85.97, 86.43, 84.09, 6700, '2008-02-18'),
(1, 1, 85.56, 84.89, 85.93, 84.65, 12500, '2008-02-19'),
(1, 1, 83.78, 83.84, 84.08, 82.8, 11300, '2008-02-20'),
(1, 1, 84.02, 82.76, 86.24, 82.6, 18400, '2008-02-21'),
(1, 1, 82.48, 80.55, 82.6, 80.28, 27200, '2008-02-22'),
(1, 1, 80.94, 79.98, 81.4, 79.1, 25500, '2008-02-25'),
(1, 1, 80.55, 79.32, 81, 77, 28100, '2008-02-26'),
(1, 1, 79.3, 79.62, 80, 78.2, 21600, '2008-02-27'),
(1, 1, 84.7, 84.36, 85.17, 83.15, 25400, '2008-02-28'),
(1, 1, 85.08, 83.84, 85.81, 83.58, 26500, '2008-02-29'),
(1, 1, 83.84, 83.84, 83.84, 83.84, 0, '2008-03-03'),
(1, 1, 80, 80, 80.59, 78.81, 35900, '2008-03-04'),
(1, 1, 82.35, 81.62, 83.1, 80.67, 12500, '2008-03-05'),
(1, 1, 82.3, 82.21, 83, 80.88, 14600, '2008-03-06'),
(1, 1, 79.35, 79.38, 80.39, 76.96, 21000, '2008-03-07'),
(1, 1, 79.6, 78.47, 81.29, 78.42, 31600, '2008-03-10'),
(1, 1, 78.06, 80.66, 81.48, 77.79, 27500, '2008-03-11'),
(1, 1, 82.8, 82.18, 83.15, 80.95, 15000, '2008-03-12'),
(1, 1, 80.15, 80.36, 80.72, 78.98, 28300, '2008-03-13'),
(1, 1, 82, 81.39, 83.74, 79.08, 18100, '2008-03-14'),
(1, 1, 78.2, 78.48, 80.14, 77, 47900, '2008-03-17'),
(1, 1, 81.1, 82.34, 82.5, 80.85, 14100, '2008-03-18'),
(1, 1, 84.12, 84.24, 85.7, 83.03, 22400, '2008-03-19'),
(1, 1, 82.78, 84, 85, 82.78, 7000, '2008-03-20'),
(1, 1, 84, 84, 84, 84, 0, '2008-03-21'),
(1, 1, 84, 84, 84, 84, 0, '2008-03-24'),
(1, 1, 89.66, 89.56, 90.17, 86.91, 17500, '2008-03-25'),
(1, 1, 90.12, 91.54, 92.1, 89.05, 22400, '2008-03-26'),
(1, 1, 91.1, 90.75, 92.1, 90.41, 18700, '2008-03-27'),
(1, 1, 90.3, 91.76, 91.78, 89.2, 11000, '2008-03-28'),
(1, 1, 90.7, 91.33, 91.91, 90.06, 9600, '2008-03-31'),
(1, 1, 91.29, 94.4, 94.89, 91.29, 11100, '2008-04-01'),
(1, 1, 96, 95.98, 96.65, 94.98, 24100, '2008-04-02'),
(1, 1, 95.46, 95.81, 96.18, 92.47, 15800, '2008-04-03'),
(1, 1, 97, 97.03, 97.99, 95.59, 11400, '2008-04-04'),
(1, 1, 98.55, 100.64, 100.69, 98.01, 17300, '2008-04-07'),
(1, 1, 98.81, 99, 99.35, 97.1, 26000, '2008-04-08'),
(1, 1, 97.27, 96, 97.91, 95.88, 16400, '2008-04-09'),
(1, 1, 96.25, 98.21, 98.42, 93.61, 20000, '2008-04-10'),
(1, 1, 98.63, 95.44, 98.9, 94.92, 10900, '2008-04-11'),
(1, 1, 93.1, 92.5, 93.78, 90.61, 16900, '2008-04-14'),
(1, 1, 93.91, 92.5, 95.01, 92.01, 9700, '2008-04-15'),
(1, 1, 94.95, 96, 96, 94.36, 15500, '2008-04-16'),
(1, 1, 97.45, 97.19, 98, 96.03, 11100, '2008-04-17'),
(1, 1, 98.69, 102.17, 102.5, 98.09, 13400, '2008-04-18'),
(1, 1, 102.4, 102.84, 106.5, 101.16, 19500, '2008-04-21'),
(1, 1, 105.31, 101.59, 106, 101.01, 33600, '2008-04-22'),
(1, 1, 101.59, 104, 104.28, 101.03, 15000, '2008-04-23'),
(1, 1, 102.85, 105.6, 106.09, 101.31, 39200, '2008-04-24'),
(1, 1, 107, 107.63, 110.1, 106.01, 28200, '2008-04-25'),
(1, 1, 108.89, 109.79, 110, 108.2, 14500, '2008-04-28'),
(1, 1, 110.6, 112, 112, 109.04, 8500, '2008-04-29'),
(1, 1, 112.3, 114.44, 114.8, 111.73, 9200, '2008-04-30'),
(1, 1, 116.7, 117.11, 118.88, 115.98, 21000, '2008-05-02'),
(1, 1, 117.11, 119.1, 119.98, 116, 14400, '2008-05-05'),
(1, 1, 119, 118.28, 119.88, 117.2, 17800, '2008-05-06'),
(1, 1, 120, 121.89, 122.1, 119.31, 18600, '2008-05-07'),
(1, 1, 119.18, 120.22, 120.4, 116.1, 13300, '2008-05-08'),
(1, 1, 119.26, 118.8, 120, 118.44, 8100, '2008-05-09'),
(1, 1, 119.07, 118.66, 119.95, 118.16, 7300, '2008-05-12'),
(1, 1, 121.06, 123.14, 123.8, 121, 14900, '2008-05-13'),
(1, 1, 123.14, 122.48, 124.41, 122.48, 12800, '2008-05-14'),
(1, 1, 120.42, 121.11, 121.61, 119.2, 18400, '2008-05-15'),
(1, 1, 122.44, 120.75, 123.28, 120.26, 17600, '2008-05-16'),
(1, 1, 120.95, 120, 120.95, 118.08, 10500, '2008-05-19'),
(1, 1, 117.9, 116.4, 118.1, 114.3, 22000, '2008-05-20'),
(1, 1, 118.35, 117.06, 119.2, 115.5, 14700, '2008-05-21'),
(1, 1, 112.69, 115.22, 115.81, 111.21, 30500, '2008-05-22'),
(1, 1, 113.02, 114.46, 115.65, 113.02, 12900, '2008-05-23'),
(1, 1, 114.53, 115.66, 116, 114.53, 5200, '2008-05-26'),
(1, 1, 115.99, 116.49, 117.2, 115.1, 7300, '2008-05-27'),
(1, 1, 118.47, 118.26, 120.4, 118.26, 10200, '2008-05-28'),
(1, 1, 119.61, 119.7, 121, 119.01, 10700, '2008-05-29'),
(1, 1, 120.5, 121.16, 121.99, 120.36, 4700, '2008-05-30'),
(1, 1, 121.12, 119.7, 122.14, 119.7, 3100, '2008-06-02'),
(1, 1, 119, 121.67, 121.7, 118.91, 10100, '2008-06-03'),
(1, 1, 120.68, 120.9, 121.03, 118.4, 9200, '2008-06-04'),
(1, 1, 119.55, 120.5, 122, 119.55, 7600, '2008-06-05'),
(1, 1, 121.94, 118.01, 122, 118.01, 15700, '2008-06-06'),
(1, 1, 115.99, 118.35, 120.85, 115.4, 30200, '2008-06-10'),
(1, 1, 120, 117.01, 120.7, 116.49, 12000, '2008-06-11'),
(1, 1, 117.49, 117, 118.61, 112.2, 24300, '2008-06-12'),
(1, 1, 112.01, 113.02, 114.17, 108, 43200, '2008-06-13'),
(1, 1, 112.07, 111.48, 112.52, 106.15, 16200, '2008-06-16'),
(1, 1, 114.3, 117, 117, 114, 9900, '2008-06-17'),
(1, 1, 117.49, 115.32, 117.89, 114.52, 9500, '2008-06-18'),
(1, 1, 114.75, 115.59, 117, 114.21, 7900, '2008-06-19'),
(1, 1, 116.52, 113.3, 116.75, 113.06, 9900, '2008-06-20'),
(1, 1, 113.42, 110.51, 114.17, 110.51, 8700, '2008-06-23'),
(1, 1, 111.2, 111.57, 112.3, 108.98, 11500, '2008-06-24'),
(1, 1, 111.03, 113.5, 114.49, 111.03, 8600, '2008-06-25'),
(1, 1, 112.24, 108.54, 112.24, 107.24, 13300, '2008-06-26'),
(1, 1, 106.75, 106.69, 107.43, 104.18, 28700, '2008-06-27'),
(1, 1, 107.65, 107.58, 109, 105.4, 19600, '2008-06-30'),
(1, 1, 106.11, 109.35, 109.42, 103.27, 15200, '2008-07-01'),
(1, 1, 111.01, 110.71, 112.89, 109, 13800, '2008-07-02'),
(1, 1, 106.3, 108.02, 109.34, 104.22, 11900, '2008-07-03'),
(1, 1, 108.02, 108.12, 108.65, 108.02, 1700, '2008-07-04'),
(1, 1, 108.4, 112.5, 112.72, 108.4, 7300, '2008-07-07'),
(1, 1, 111.8, 111.61, 113.11, 110.21, 7300, '2008-07-08'),
(1, 1, 114.59, 113, 115.72, 113, 9200, '2008-07-09'),
(1, 1, 111.87, 111.51, 113.38, 110.46, 16200, '2008-07-10'),
(1, 1, 111.79, 109.23, 112.76, 109, 15900, '2008-07-11'),
(1, 1, 109.15, 110.83, 113.48, 109.15, 14100, '2008-07-14'),
(1, 1, 109.2, 107.3, 109.2, 104.38, 21200, '2008-07-15'),
(1, 1, 107.27, 107.1, 108.21, 104.62, 13100, '2008-07-16'),
(1, 1, 109.3, 109.66, 110.5, 108.48, 11600, '2008-07-17'),
(1, 1, 106.8, 105.98, 108.18, 105.4, 4900, '2008-07-18'),
(1, 1, 105.68, 103.42, 105.7, 102.79, 8300, '2008-07-21'),
(1, 1, 93.9, 97.24, 97.24, 92.5, 51400, '2008-07-22'),
(1, 1, 102.66, 105.76, 108, 101.71, 17900, '2008-07-23'),
(1, 1, 106.88, 101.38, 106.88, 101.38, 8400, '2008-07-24'),
(1, 1, 101.74, 102.67, 102.67, 101, 11800, '2008-07-25'),
(1, 1, 103.5, 100.5, 103.8, 100.5, 12000, '2008-07-28'),
(1, 1, 98.08, 100.24, 102, 97.72, 20000, '2008-07-29'),
(1, 1, 101.29, 102.33, 103, 100.6, 8200, '2008-07-30'),
(1, 1, 102, 102.79, 103.83, 99.99, 7000, '2008-07-31'),
(1, 1, 101.66, 100.71, 103.05, 100.4, 4500, '2008-08-01'),
(1, 1, 100.84, 101, 101.28, 99.65, 8600, '2008-08-04'),
(1, 1, 99.29, 102, 102, 98.75, 7900, '2008-08-05'),
(1, 1, 103.79, 104, 104, 102.91, 6300, '2008-08-06'),
(1, 1, 105.15, 106.52, 107.25, 104.7, 11700, '2008-08-07'),
(1, 1, 107.51, 111, 111.2, 107.51, 11200, '2008-08-08'),
(1, 1, 112.98, 116.2, 116.23, 112.62, 15900, '2008-08-11'),
(1, 1, 116.79, 119.65, 120.03, 115, 27600, '2008-08-12'),
(1, 1, 118.06, 119.58, 121, 116.53, 16100, '2008-08-13'),
(1, 1, 119.95, 120.72, 121.04, 119.26, 15300, '2008-08-14'),
(1, 1, 121.59, 121.83, 122, 119.56, 16300, '2008-08-15'),
(1, 1, 118.01, 120.55, 120.7, 118.01, 6100, '2008-08-18'),
(1, 1, 119.3, 120.08, 120.3, 118.51, 9600, '2008-08-19'),
(1, 1, 117.6, 119.6, 120.12, 117.6, 7700, '2008-08-20'),
(1, 1, 118.48, 115.98, 118.48, 115.56, 8700, '2008-08-21'),
(1, 1, 116.81, 119.24, 119.5, 115.93, 1300, '2008-08-22'),
(1, 1, 120.19, 118.03, 120.35, 117.7, 2500, '2008-08-25'),
(1, 1, 117.31, 118.41, 119, 117.31, 3500, '2008-08-26'),
(1, 1, 117.94, 118.07, 118.42, 117, 1100, '2008-08-27'),
(1, 1, 118.08, 119.25, 119.5, 117.75, 2700, '2008-08-28'),
(1, 1, 117.4, 116.4, 117.88, 116.38, 4200, '2008-08-29'),
(1, 1, 115.99, 116.39, 116.8, 114.39, 2700, '2008-09-01'),
(1, 1, 116.99, 118.2, 119.5, 116.3, 9100, '2008-09-02'),
(1, 1, 115.88, 114.99, 117.39, 114.56, 10400, '2008-09-03'),
(1, 1, 115.48, 114.87, 116.43, 114.51, 9900, '2008-09-04'),
(1, 1, 112.27, 111, 113.32, 109.34, 12900, '2008-09-05'),
(1, 1, 113.6, 108.89, 115.99, 108.89, 16100, '2008-09-08'),
(1, 1, 111.1, 111.49, 113.08, 110.75, 15800, '2008-09-09'),
(1, 1, 108.99, 108.2, 108.99, 104.78, 17500, '2008-09-10'),
(1, 1, 107.95, 107.01, 108.45, 105, 10900, '2008-09-11'),
(1, 1, 109.3, 105.37, 109.3, 103.54, 10800, '2008-09-12'),
(1, 1, 101.51, 102.86, 103.97, 98.7, 26500, '2008-09-15'),
(1, 1, 98.14, 96.25, 98.65, 92.15, 33500, '2008-09-16'),
(1, 1, 99.75, 93.27, 99.88, 91.5, 24200, '2008-09-17'),
(1, 1, 89.02, 87.47, 91.85, 85.8, 17100, '2008-09-18'),
(1, 1, 96.3, 98.15, 102.48, 96.09, 27500, '2008-09-19'),
(1, 1, 98.21, 93.26, 98.21, 93.26, 10000, '2008-09-22'),
(1, 1, 89.8, 90.89, 92.18, 88.5, 14400, '2008-09-23'),
(1, 1, 88.7, 88.68, 88.7, 85.55, 8000, '2008-09-24'),
(1, 1, 86.97, 90.5, 90.5, 86.97, 7600, '2008-09-25'),
(1, 1, 87.79, 86.49, 87.79, 83.9, 16700, '2008-09-26'),
(1, 1, 88.18, 77.15, 88.18, 72.5, 34000, '2008-09-29'),
(1, 1, 72.9, 77.79, 79.5, 71.26, 55400, '2008-09-30'),
(1, 1, 80.86, 77.57, 81.47, 76.89, 12600, '2008-10-01'),
(1, 1, 79.44, 75, 80.24, 72.1, 14400, '2008-10-02'),
(1, 1, 72.66, 75.5, 77, 70, 22500, '2008-10-03'),
(1, 1, 69.6, 67.75, 70, 64.88, 33400, '2008-10-06'),
(1, 1, 72.5, 69.6, 73.75, 68.37, 34200, '2008-10-07'),
(1, 1, 63.02, 68.03, 69, 60.5, 67500, '2008-10-08'),
(1, 1, 66.88, 67.23, 69.69, 65.78, 18000, '2008-10-09'),
(1, 1, 61.2, 67.44, 70.85, 61.16, 29800, '2008-10-10'),
(1, 1, 75.01, 76.62, 78, 74.5, 34300, '2008-10-13'),
(1, 1, 84, 79.62, 85.5, 78, 38100, '2008-10-14'),
(1, 1, 78.99, 77.18, 78.99, 74.5, 27700, '2008-10-15'),
(1, 1, 71.6, 70.28, 75.4, 68.71, 29000, '2008-10-16'),
(1, 1, 77.5, 73.37, 77.9, 72.55, 17700, '2008-10-17');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `test_Tabelle`
--

CREATE TABLE IF NOT EXISTS `test_Tabelle` (
  `sdf` varchar(255) collate utf8_unicode_ci NOT NULL,
  KEY `sdf` (`sdf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `test_Tabelle`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `nickname` varchar(20) collate utf8_unicode_ci NOT NULL,
  `password` varchar(255) collate utf8_unicode_ci NOT NULL,
  `role` varchar(6) collate utf8_unicode_ci NOT NULL default 'member',
  `lastname` varchar(35) collate utf8_unicode_ci NOT NULL,
  `firstname` varchar(35) collate utf8_unicode_ci NOT NULL,
  `email` varchar(55) collate utf8_unicode_ci NOT NULL,
  `reg_date` int(10) unsigned NOT NULL,
  `edit_date` int(10) unsigned NOT NULL,
  `newsletter` enum('y','n') collate utf8_unicode_ci NOT NULL default 'n',
  `picture_id` int(10) unsigned default NULL,
  `status` tinyint(1) unsigned NOT NULL default '1',
  `invitations` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`nickname`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Daten für Tabelle `users`
--

INSERT INTO `users` (`user_id`, `nickname`, `password`, `role`, `lastname`, `firstname`, `email`, `reg_date`, `edit_date`, `newsletter`, `picture_id`, `status`, `invitations`) VALUES
(1, 'mb', 'af16f56fffe8f9d2a314b8542ab185d2', 'admin', 'B√∂ttcher', 'Martin', 'mb@mb-designz.de', 1211120890, 0, 'y', NULL, 1, 0),
(3, 'system', 'af16f56fffe8f9d2a314b8542ab185d2', 'member', 'System', 'Mr.', 'mail@rule1tool.com', 1217184376, 1217184376, 'y', NULL, 1, 0),
(4, 'tester1', '202cb962ac59075b964b07152d234b70', 'member', 'test', 'tester', 'test@rule1tool.com', 1217921264, 1217921264, 'n', NULL, 1, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `watchlist`
--

CREATE TABLE IF NOT EXISTS `watchlist` (
  `watchlist_id` int(10) unsigned NOT NULL auto_increment,
  `owner_id` int(10) unsigned NOT NULL,
  `date_add` int(10) unsigned NOT NULL,
  `date_edit` int(10) unsigned NOT NULL,
  `date_delete` int(10) unsigned default NULL,
  `delete_by` int(10) unsigned default NULL,
  PRIMARY KEY  (`watchlist_id`),
  KEY `owner_id` (`owner_id`),
  KEY `delete_by` (`delete_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `watchlist`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `watchlist_companies`
--

CREATE TABLE IF NOT EXISTS `watchlist_companies` (
  `watchlist_id` int(10) unsigned NOT NULL,
  `company_id` int(10) unsigned NOT NULL,
  `market_id` tinyint(4) NOT NULL,
  `date_add` int(10) unsigned NOT NULL,
  `date_edit` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`watchlist_id`,`company_id`),
  KEY `market_id` (`market_id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `watchlist_companies`
--


--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `analysisfavourits`
--
ALTER TABLE `analysisfavourits`
  ADD CONSTRAINT `analysisfavourits_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `analysisfavourits_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `analysisfavourits_ibfk_3` FOREIGN KEY (`analysis_id`) REFERENCES `keydataanalyses` (`analysis_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `availablestocksonexchanges`
--
ALTER TABLE `availablestocksonexchanges`
  ADD CONSTRAINT `availablestocksonexchanges_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `availablestocksonexchanges_ibfk_3` FOREIGN KEY (`market_id`) REFERENCES `stockexchanges` (`market_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `companies_ibfk_1` FOREIGN KEY (`main_market`) REFERENCES `stockexchanges` (`market_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `companies_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `gruppen` (`id`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `gruppen`
--
ALTER TABLE `gruppen`
  ADD CONSTRAINT `gruppen_ibfk_29` FOREIGN KEY (`founder_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `gruppen_ibfk_30` FOREIGN KEY (`delete_by`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `gruppen_lokalisierung`
--
ALTER TABLE `gruppen_lokalisierung`
  ADD CONSTRAINT `gruppen_lokalisierung_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `gruppen` (`id`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `gruppen_members`
--
ALTER TABLE `gruppen_members`
  ADD CONSTRAINT `gruppen_members_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `gruppen` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gruppen_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gruppen_members_ibfk_3` FOREIGN KEY (`mtype_id`) REFERENCES `gruppen_membertypes` (`mtype_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `gruppen_members_ibfk_4` FOREIGN KEY (`delete_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `gruppen_threads`
--
ALTER TABLE `gruppen_threads`
  ADD CONSTRAINT `gruppen_threads_ibfk_22` FOREIGN KEY (`group_id`) REFERENCES `gruppen` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gruppen_threads_ibfk_26` FOREIGN KEY (`type`) REFERENCES `gruppen_thread_typs` (`type_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `gruppen_threads_ibfk_27` FOREIGN KEY (`founder_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `gruppen_threads_ibfk_28` FOREIGN KEY (`delete_by`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `gruppen_threads_ibfk_29` FOREIGN KEY (`analysis_id`) REFERENCES `keydataanalyses` (`analysis_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `gruppen_thread_replies`
--
ALTER TABLE `gruppen_thread_replies`
  ADD CONSTRAINT `gruppen_thread_replies_ibfk_1` FOREIGN KEY (`thread_id`) REFERENCES `gruppen_threads` (`thread_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gruppen_thread_replies_ibfk_3` FOREIGN KEY (`writer_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `gruppen_thread_replies_ibfk_4` FOREIGN KEY (`delete_by`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `invitations`
--
ALTER TABLE `invitations`
  ADD CONSTRAINT `invitations_ibfk_1` FOREIGN KEY (`invitor`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `invitations_ibfk_2` FOREIGN KEY (`invited`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `keydataanalyses`
--
ALTER TABLE `keydataanalyses`
  ADD CONSTRAINT `keydataanalyses_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `keydataanalyses_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `keydataanalyses_ibfk_3` FOREIGN KEY (`delete_by`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `keydataanalyses_data`
--
ALTER TABLE `keydataanalyses_data`
  ADD CONSTRAINT `keydataanalyses_data_ibfk_1` FOREIGN KEY (`analysis_id`) REFERENCES `keydataanalyses` (`analysis_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `new_companies`
--
ALTER TABLE `new_companies`
  ADD CONSTRAINT `new_companies_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `registrations`
--
ALTER TABLE `registrations`
  ADD CONSTRAINT `registrations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `stockexchanges`
--
ALTER TABLE `stockexchanges`
  ADD CONSTRAINT `stockexchanges_ibfk_1` FOREIGN KEY (`countrycode`) REFERENCES `countrycodes` (`ALPHA2`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `stockquotes_eod`
--
ALTER TABLE `stockquotes_eod`
  ADD CONSTRAINT `stockquotes_eod_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `stockquotes_eod_ibfk_2` FOREIGN KEY (`market_id`) REFERENCES `stockexchanges` (`market_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `watchlist`
--
ALTER TABLE `watchlist`
  ADD CONSTRAINT `watchlist_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `watchlist_ibfk_2` FOREIGN KEY (`delete_by`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `watchlist_companies`
--
ALTER TABLE `watchlist_companies`
  ADD CONSTRAINT `watchlist_companies_ibfk_1` FOREIGN KEY (`watchlist_id`) REFERENCES `watchlist` (`watchlist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `watchlist_companies_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `watchlist_companies_ibfk_3` FOREIGN KEY (`market_id`) REFERENCES `stockexchanges` (`market_id`) ON UPDATE CASCADE;
